<!DOCTYPE html>
<!--[if IE 8]>
<html class="no-js g1-off-outside lt-ie10 lt-ie9" id="ie8" lang="en-US" prefix="og: https://ogp.me/ns#"><![endif]-->
<!--[if IE 9]>
<html class="no-js g1-off-outside lt-ie10" id="ie9" lang="en-US" prefix="og: https://ogp.me/ns#"><![endif]-->
<!--[if !IE]><!-->
<html class="no-js g1-off-outside" lang="en-US" prefix="og: https://ogp.me/ns#"><!--<![endif]-->
<head>
	<meta charset="UTF-8"/>
	<link rel="profile" href="https://gmpg.org/xfn/11"/>
	<link rel="pingback" href="https://html.design/xmlrpc.php"/>

	
<meta name="viewport" content="initial-scale=1.0, minimum-scale=1.0, height=device-height, width=device-width" />

<!-- Search Engine Optimization by Rank Math PRO - https://s.rankmath.com/home -->
<title>Nothing found for</title>
<meta name="robots" content="follow, noindex"/>
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="article" />
<meta property="og:title" content="Nothing found for" />
<meta property="og:site_name" content="HTML Design" />
<meta property="article:publisher" content="https://facebook.com/htmldotdesign" />
<meta name="twitter:card" content="summary" />
<meta name="twitter:title" content="Nothing found for" />
<meta name="twitter:site" content="@https://twitter.com/htmldotdesign" />
<script type="application/ld+json" class="rank-math-schema-pro">{"@context":"https://schema.org","@graph":[{"@type":"Place","@id":"https://html.design/#place","address":{"@type":"PostalAddress","streetAddress":"PRAHLAD NAGAR","addressLocality":"AHMEDABAD","addressRegion":"Gujurat","postalCode":"380015","addressCountry":"INDIA"}},{"@type":"ProfessionalService","@id":"https://html.design/#organization","name":"HTML Design","url":"https://html.design","email":"htmldotdesign@gmail.com","address":{"@type":"PostalAddress","streetAddress":"PRAHLAD NAGAR","addressLocality":"AHMEDABAD","addressRegion":"Gujurat","postalCode":"380015","addressCountry":"INDIA"},"logo":{"@type":"ImageObject","@id":"https://html.design/#logo","url":"https://html.design/wp-content/uploads/2019/04/logo-html-design-2.png","contentUrl":"https://html.design/wp-content/uploads/2019/04/logo-html-design-2.png","caption":"HTML Design","inLanguage":"en-US","width":"316","height":"50"},"priceRange":"$99","openingHours":["Monday,Tuesday,Wednesday,Thursday,Friday,Saturday,Sunday 09:00-17:00"],"location":{"@id":"https://html.design/#place"},"image":{"@id":"https://html.design/#logo"},"telephone":"+919555666706"},{"@type":"WebSite","@id":"https://html.design/#website","url":"https://html.design","name":"HTML Design","publisher":{"@id":"https://html.design/#organization"},"inLanguage":"en-US"},{"@type":"WebPage","@id":"#webpage","url":"","name":"Nothing found for","isPartOf":{"@id":"https://html.design/#website"},"inLanguage":"en-US"}]}</script>
<!-- /Rank Math WordPress SEO plugin -->

<link rel='dns-prefetch' href='//www.google.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='preconnect' href='https://fonts.gstatic.com' />
<link rel="alternate" type="application/rss+xml" title="HTML Design &raquo; Feed" href="https://html.design/feed/" />
<link rel="alternate" type="application/rss+xml" title="HTML Design &raquo; Comments Feed" href="https://html.design/comments/feed/" />
<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 0.07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wpapp-styles-css'  href='https://html.design/wp-content/plugins/wordpress-easy-paypal-payment-or-donation-accept-plugin/wpapp-styles.css?ver=6.0.2' type='text/css' media='all' />
<style id='restrict-content-pro-content-upgrade-redirect-style-inline-css' type='text/css'>
.wp-block-restrict-content-pro-content-upgrade-redirect .wp-block-button__width-25 {
  width: calc(25% - 0.5rem);
}
.wp-block-restrict-content-pro-content-upgrade-redirect .wp-block-button__width-25 .wp-block-button__link {
  width: 100%;
}
.wp-block-restrict-content-pro-content-upgrade-redirect .wp-block-button__width-50 {
  width: calc(50% - 0.5rem);
}
.wp-block-restrict-content-pro-content-upgrade-redirect .wp-block-button__width-50 .wp-block-button__link {
  width: 100%;
}
.wp-block-restrict-content-pro-content-upgrade-redirect .wp-block-button__width-75 {
  width: calc(75% - 0.5rem);
}
.wp-block-restrict-content-pro-content-upgrade-redirect .wp-block-button__width-75 .wp-block-button__link {
  width: 100%;
}
.wp-block-restrict-content-pro-content-upgrade-redirect .wp-block-button__width-100 {
  margin-right: 0;
  width: 100%;
}
.wp-block-restrict-content-pro-content-upgrade-redirect .wp-block-button__width-100 .wp-block-button__link {
  width: 100%;
}

/*# sourceMappingURL=style-content-upgrade-redirect.css.map*/
</style>
<style id='global-styles-inline-css' type='text/css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--duotone--dark-grayscale: url('#wp-duotone-dark-grayscale');--wp--preset--duotone--grayscale: url('#wp-duotone-grayscale');--wp--preset--duotone--purple-yellow: url('#wp-duotone-purple-yellow');--wp--preset--duotone--blue-red: url('#wp-duotone-blue-red');--wp--preset--duotone--midnight: url('#wp-duotone-midnight');--wp--preset--duotone--magenta-yellow: url('#wp-duotone-magenta-yellow');--wp--preset--duotone--purple-green: url('#wp-duotone-purple-green');--wp--preset--duotone--blue-orange: url('#wp-duotone-blue-orange');--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
</style>
<link rel='stylesheet' id='adace-style-css'  href='https://html.design/wp-content/plugins/ad-ace/assets/css/style.min.css?ver=1.3.26' type='text/css' media='all' />
<link rel='stylesheet' id='shoppable-images-css-css'  href='https://html.design/wp-content/plugins/ad-ace/assets/css/shoppable-images-front.min.css?ver=1.3.26' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='https://html.design/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.6.3' type='text/css' media='all' />
<link rel='stylesheet' id='mashsb-styles-css'  href='https://html.design/wp-content/plugins/mashsharer/assets/css/mashsb.min.css?ver=3.8.5' type='text/css' media='all' />
<style id='mashsb-styles-inline-css' type='text/css'>
.mashsb-count {color:#cccccc;}@media only screen and (min-width:568px){.mashsb-buttons a {min-width: 177px;}}
</style>
<link rel='stylesheet' id='mace-lazy-load-youtube-css'  href='https://html.design/wp-content/plugins/media-ace/includes/lazy-load/assets/css/youtube.min.css?ver=1.4.12' type='text/css' media='all' />
<link rel='stylesheet' id='mace-gallery-css'  href='https://html.design/wp-content/plugins/media-ace/includes/gallery/css/gallery.min.css?ver=6.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='jquery-magnific-popup-css'  href='https://html.design/wp-content/plugins/snax/assets/js/jquery.magnific-popup/magnific-popup.css?ver=6.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='snax-css'  href='https://html.design/wp-content/plugins/snax/css/snax.min.css?ver=1.92' type='text/css' media='all' />
<link rel='stylesheet' id='wyr-main-css'  href='https://html.design/wp-content/plugins/whats-your-reaction/css/main.min.css?ver=1.3.18' type='text/css' media='all' />
<link rel='stylesheet' id='wordpress-popular-posts-css-css'  href='https://html.design/wp-content/plugins/wordpress-popular-posts/assets/css/wpp.css?ver=6.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='g1-main-css'  href='https://html.design/wp-content/themes/bimber/css/9.2.1/styles/cards/all-light.min.css?ver=9.2.1' type='text/css' media='all' />
<link crossorigin="anonymous" rel='stylesheet' id='bimber-google-fonts-css'  href='//fonts.googleapis.com/css?family=Roboto%3A400%2C300%2C500%2C600%2C700%2C900%7CPoppins%3A400%2C300%2C500%2C600%2C700&#038;subset=latin%2Clatin-ext&#038;display=swap&#038;ver=9.2.1' type='text/css' media='all' />
<link rel='stylesheet' id='bimber-dynamic-style-css'  href='https://html.design/wp-content/uploads/dynamic-style-1643787574.css' type='text/css' media='all' />
<link rel='stylesheet' id='js_composer_front-css'  href='https://html.design/wp-content/plugins/js_composer/assets/css/js_composer.min.css?ver=6.9.0' type='text/css' media='all' />
<link rel='stylesheet' id='bimber-snax-extra-css'  href='https://html.design/wp-content/themes/bimber/css/9.2.1/styles/cards/snax-extra-light.min.css?ver=9.2.1' type='text/css' media='all' />
<link rel='stylesheet' id='bimber-dlm-css'  href='https://html.design/wp-content/themes/bimber/css/9.2.1/styles/cards/dlm-light.min.css?ver=9.2.1' type='text/css' media='all' />
<link rel='stylesheet' id='bimber-vc-css'  href='https://html.design/wp-content/themes/bimber/css/9.2.1/styles/cards/vc-light.min.css?ver=9.2.1' type='text/css' media='all' />
<link rel='stylesheet' id='bimber-mashshare-css'  href='https://html.design/wp-content/themes/bimber/css/9.2.1/styles/cards/mashshare-light.min.css?ver=9.2.1' type='text/css' media='all' />
<link rel='stylesheet' id='wpgdprc-front-css-css'  href='https://html.design/wp-content/plugins/wp-gdpr-compliance/Assets/css/front.css?ver=1663747006' type='text/css' media='all' />
<style id='wpgdprc-front-css-inline-css' type='text/css'>
:root{--wp-gdpr--bar--background-color: #000000;--wp-gdpr--bar--color: #ffffff;--wp-gdpr--button--background-color: #000000;--wp-gdpr--button--background-color--darken: #000000;--wp-gdpr--button--color: #ffffff;}
</style>
<script type='text/javascript' src='https://html.design/wp-includes/js/jquery/jquery.min.js?ver=3.6.0' id='jquery-core-js'></script>
<script type='text/javascript' src='https://html.design/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type='text/javascript' src='https://html.design/wp-content/plugins/ad-ace/assets/js/slot-slideup.js?ver=1.3.26' id='adace-slot-slideup-js'></script>
<script type='text/javascript' src='https://html.design/wp-content/plugins/ad-ace/includes/shoppable-images/assets/js/shoppable-images-front.js?ver=1.3.26' id='shoppable-images-js-js'></script>
<script type='text/javascript' src='https://html.design/wp-content/plugins/ad-ace/assets/js/coupons.js?ver=1.3.26' id='adace-coupons-js'></script>
<script type='text/javascript' id='cf7pp-redirect_method-js-extra'>
/* <![CDATA[ */
var ajax_object_cf7pp = {"ajax_url":"https:\/\/html.design\/wp-admin\/admin-ajax.php","forms":"[\"12054|paypal\",\"8478|paypal\",\"5326|paypal\"]","path_paypal":"https:\/\/html.design\/?cf7pp_paypal_redirect=","path_stripe":"https:\/\/html.design\/?cf7pp_stripe_redirect=","method":"2"};
/* ]]> */
</script>
<script type='text/javascript' src='https://html.design/wp-content/plugins/contact-form-7-paypal-add-on/assets/js/redirect_method.js?ver=1.9.3' id='cf7pp-redirect_method-js'></script>
<script type='text/javascript' id='mashsb-js-extra'>
/* <![CDATA[ */
var mashsb = {"shares":"0","round_shares":"1","animate_shares":"0","dynamic_buttons":"0","share_url":"https:\/\/html.design\/download\/birdim-bird-care-html-template\/","title":"Birdim+%E2%80%93+Bird+Care+HTML+Template","image":"https:\/\/html.design\/wp-content\/uploads\/2020\/01\/birdim.jpg","desc":"Birdim - Bird Care HTML Template is a uniquely HTML template develop in HTML with a modern look organized and named accordingly so its very easy to customize and update.\r\n\r\nLicense : Creative Commons 3.0 \u2013 \u2026","hashtag":"htmldotdesign","subscribe":"content","subscribe_url":"","activestatus":"1","singular":"0","twitter_popup":"1","refresh":"0","nonce":"10eb154280","postid":"","servertime":"1663819132","ajaxurl":"https:\/\/html.design\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type='text/javascript' src='https://html.design/wp-content/plugins/mashsharer/assets/js/mashsb.min.js?ver=3.8.5' id='mashsb-js'></script>
<script type='application/json' id='wpp-json'>
{"sampling_active":0,"sampling_rate":100,"ajax_url":"https:\/\/html.design\/wp-json\/wordpress-popular-posts\/v1\/popular-posts","api_url":"https:\/\/html.design\/wp-json\/wordpress-popular-posts","ID":0,"token":"71f0ed8155","lang":0,"debug":0}
</script>
<script type='text/javascript' src='https://html.design/wp-content/plugins/wordpress-popular-posts/assets/js/wpp.min.js?ver=6.0.5' id='wpp-js-js'></script>
<script type='text/javascript' src='https://html.design/wp-content/themes/bimber/js/modernizr/modernizr-custom.min.js?ver=3.3.0' id='modernizr-js'></script>
<script type='text/javascript' id='wpgdprc-front-js-js-extra'>
/* <![CDATA[ */
var wpgdprcFront = {"ajaxUrl":"https:\/\/html.design\/wp-admin\/admin-ajax.php","ajaxNonce":"4d1011a2ba","ajaxArg":"security","pluginPrefix":"wpgdprc","blogId":"1","isMultiSite":"","locale":"en_US","showSignUpModal":"","showFormModal":"","cookieName":"wpgdprc-consent-3","consentVersion":"3","path":"\/","prefix":"wpgdprc","consents":[{"ID":1,"required":false,"placement":"head","content":"<script type=\"text\/javascript\"> <\/script>"}]};
/* ]]> */
</script>
<script type='text/javascript' src='https://html.design/wp-content/plugins/wp-gdpr-compliance/Assets/js/front.min.js?ver=1663747006' id='wpgdprc-front-js-js'></script>
<link rel="https://api.w.org/" href="https://html.design/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://html.design/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://html.design/wp-includes/wlwmanifest.xml" /> 
<link rel="preload" href="https://html.design/wp-content/plugins/g1-socials/css/iconfont/fonts/g1-socials.woff" as="font" type="font/woff" crossorigin="anonymous">	<style>
		.lazyload, .lazyloading {
			opacity: 0;
		}
		.lazyloaded {
			opacity: 1;
		}
		.lazyload,
		.lazyloading,
		.lazyloaded {
			transition: opacity 0.175s ease-in-out;
		}

		iframe.lazyloading {
			opacity: 1;
			transition: opacity 0.375s ease-in-out;
			background: #f2f2f2 no-repeat center;
		}
		iframe.lazyloaded {
			opacity: 1;
		}
	</style>
	<link rel="preload" href="https://html.design/wp-content/plugins/snax/css/snaxicon/fonts/snaxicon.woff" as="font" type="font/woff" crossorigin="anonymous">            <style id="wpp-loading-animation-styles">@-webkit-keyframes bgslide{from{background-position-x:0}to{background-position-x:-200%}}@keyframes bgslide{from{background-position-x:0}to{background-position-x:-200%}}.wpp-widget-placeholder,.wpp-widget-block-placeholder{margin:0 auto;width:60px;height:3px;background:#dd3737;background:linear-gradient(90deg,#dd3737 0%,#571313 10%,#dd3737 100%);background-size:200% auto;border-radius:3px;-webkit-animation:bgslide 1s infinite linear;animation:bgslide 1s infinite linear}</style>
            	<style>
	@font-face {
		font-family: "bimber";
							src:url("https://html.design/wp-content/themes/bimber/css/9.2.1/bimber/fonts/bimber.eot");
			src:url("https://html.design/wp-content/themes/bimber/css/9.2.1/bimber/fonts/bimber.eot?#iefix") format("embedded-opentype"),
			url("https://html.design/wp-content/themes/bimber/css/9.2.1/bimber/fonts/bimber.woff") format("woff"),
			url("https://html.design/wp-content/themes/bimber/css/9.2.1/bimber/fonts/bimber.ttf") format("truetype"),
			url("https://html.design/wp-content/themes/bimber/css/9.2.1/bimber/fonts/bimber.svg#bimber") format("svg");
				font-weight: normal;
		font-style: normal;
		font-display: block;
	}
	</style>
	<script src="//m.servedby-buysellads.com/monetization.js" type="text/javascript"></script>

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-45529136-9"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-45529136-9');
</script>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5b0bfd5210b99c7b36d46197/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
      <meta name="onesignal" content="wordpress-plugin"/>
            <script>

      window.OneSignal = window.OneSignal || [];

      OneSignal.push( function() {
        OneSignal.SERVICE_WORKER_UPDATER_PATH = "OneSignalSDKUpdaterWorker.js.php";
                      OneSignal.SERVICE_WORKER_PATH = "OneSignalSDKWorker.js.php";
                      OneSignal.SERVICE_WORKER_PARAM = { scope: "/" };
        OneSignal.setDefaultNotificationUrl("https://html.design");
        var oneSignal_options = {};
        window._oneSignalInitOptions = oneSignal_options;

        oneSignal_options['wordpress'] = true;
oneSignal_options['appId'] = 'ac7f2330-d8e6-4a35-9df1-9fd8cb48ca89';
oneSignal_options['allowLocalhostAsSecureOrigin'] = true;
oneSignal_options['welcomeNotification'] = { };
oneSignal_options['welcomeNotification']['title'] = "";
oneSignal_options['welcomeNotification']['message'] = "";
oneSignal_options['path'] = "https://html.design/wp-content/plugins/onesignal-free-web-push-notifications/sdk_files/";
oneSignal_options['persistNotification'] = true;
oneSignal_options['promptOptions'] = { };
oneSignal_options['promptOptions']['siteName'] = "HTML Design";
oneSignal_options['notifyButton'] = { };
oneSignal_options['notifyButton']['enable'] = true;
oneSignal_options['notifyButton']['position'] = 'bottom-right';
oneSignal_options['notifyButton']['theme'] = 'default';
oneSignal_options['notifyButton']['size'] = 'large';
oneSignal_options['notifyButton']['showCredit'] = true;
oneSignal_options['notifyButton']['text'] = {};
oneSignal_options['notifyButton']['offset'] = {};
                OneSignal.init(window._oneSignalInitOptions);
                OneSignal.showSlidedownPrompt();      });

      function documentInitOneSignal() {
        var oneSignal_elements = document.getElementsByClassName("OneSignal-prompt");

        var oneSignalLinkClickHandler = function(event) { OneSignal.push(['registerForPushNotifications']); event.preventDefault(); };        for(var i = 0; i < oneSignal_elements.length; i++)
          oneSignal_elements[i].addEventListener('click', oneSignalLinkClickHandler, false);
      }

      if (document.readyState === 'complete') {
           documentInitOneSignal();
      }
      else {
           window.addEventListener("load", function(event){
               documentInitOneSignal();
          });
      }
    </script>
<meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<!-- There is no amphtml version available for this URL. --><script id="google_gtagjs" src="https://www.googletagmanager.com/gtag/js?id=UA-45529136-9" async="async" type="text/javascript"></script>
<script id="google_gtagjs-inline" type="text/javascript">
window.dataLayer = window.dataLayer || [];function gtag(){dataLayer.push(arguments);}gtag('set', 'linker', {"domains":["html.design"]} );gtag('js', new Date());gtag('config', 'UA-45529136-9', {} );
</script>
<link rel="icon" href="https://html.design/wp-content/uploads/2019/04/cropped-logo-html-design-2-32x32.png" sizes="32x32" />
<link rel="icon" href="https://html.design/wp-content/uploads/2019/04/cropped-logo-html-design-2-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://html.design/wp-content/uploads/2019/04/cropped-logo-html-design-2-180x180.png" />
<meta name="msapplication-TileImage" content="https://html.design/wp-content/uploads/2019/04/cropped-logo-html-design-2-270x270.png" />
	<script>if("undefined"!=typeof localStorage){var nsfwItemId=document.getElementsByName("g1:nsfw-item-id");nsfwItemId=nsfwItemId.length>0?nsfwItemId[0].getAttribute("content"):"g1_nsfw_off",window.g1SwitchNSFW=function(e){e?(localStorage.setItem(nsfwItemId,1),document.documentElement.classList.add("g1-nsfw-off")):(localStorage.removeItem(nsfwItemId),document.documentElement.classList.remove("g1-nsfw-off"))};try{var nsfwmode=localStorage.getItem(nsfwItemId);window.g1SwitchNSFW(nsfwmode)}catch(e){}}</script>
			<style type="text/css" id="wp-custom-css">
			.g1-quick-nav-menu span:before  {
	color:#fff !important;
	opacity:1 !important;
	font-size:17px !important;
}
.g1-quick-nav-menu span  {
	background:#e80404 !important
}


.g1-dark [type=email], .g1-dark select {
    border-color: rgba(255,255,255, 0.8);
}

p,
li,
h1,
h2,
h4,
h3,
h5,
body {
	letter-spacing:-0.5px !important;
}

body.home .page-header-01 {
	display:none;
}
.page-subtitle {
    margin-top: 0;
}
@media only screen and (min-width: 1025px) {
.g1-gamma, h3 {
    font-size: 15px !important;
	}}

li#menu-item-6924 {
background: black !important;
}

li#menu-item-5543 {
    background: #09a0d9 !important;
}
li#menu-item-8483 {
    background: #ecb20b !important;
}
li#menu-item-6924:hover a, li#menu-item-6924:focus a {
    color: #fff !important;
}

li#menu-item-6924.current-menu-item a {
    color: #fff;
}
.adace-slot-wrapper.adace-shortcode-7006.adace-align-center {
    float: right;
    margin-top: -85px;
}

.g1-secondary-nav-menu li:last-child a {
    margin-right: 0 !important;
}

.g1-hb-row .g1-secondary-nav-menu > .menu-item > a {
    padding: 8px 0;
    margin-right: 54px;
}

.g1-secondary-nav-menu > .menu-item > a {
	font-size: 14px;
}

.g1-row.g1-row-layout-page.g1-hb-row.g1-hb-row-normal.g1-hb-row-a.g1-hb-row-1.g1-hb-boxed.g1-hb-sticky-off.g1-hb-shadow-off {
border-bottom: solid 1px
    #eee;
}

.entry-flag.entry-flag-latest {
    background: 
    #327ceb !important;
}

.entry-flag.entry-flag-popular {
    background: 
    #f4c214 !important;
}

.entry-flag.entry-flag-trending {
    background: 
    #8ac31c !important;
}

h1 + p.lead {
    position: relative;
    top: -5px;
    font-size: 15px !important;
}

#page .g1-quick-nav-short .menu-item .entry-flag {
    width: 2em;
    height: 2em;
    margin-bottom: .2em;
    font-size: 16px;
    line-height: 1;
}

@media (max-width: 767px) {
	
.g1-logo-wrapper .g1-logo {
    width: 200px;
}	

.adace-slot-wrapper.adace-shortcode-7006.adace-align-center {
    float: none;
    margin: -5px auto -5px;
    display: flex;
    justify-content: center;
}	
	
}


.g1-collection-item article .g1-gamma.entry-title a {
    font-size: 15px;
    color: #222;
    padding: 5px 0 3px 15px;
    float: left;
}

.g1-collection-item article .g1-gamma.entry-title a:hover,
.g1-collection-item article .g1-gamma.entry-title a:focus {
    color: #ff0036;
}

li.g1-collection-item article .g1-gamma.g1-gamma-1st.entry-title {
    float: left;
    width: 100%;
    padding: 0;
    margin: 0;
    line-height: 38px;
}

header.entry-header .entry-stats {
    padding-left: 5px;
    padding-top: 2px;
}
.g1-collection-item article {
    float: left;
    width: 100%;
}

/** new style css **/

.g1-logo-wrapper .g1-logo img {
    width: 210px;
}


.g1-hb-row-c .g1-row-background {
    background-color: #f7f7f7 !important;
}


.g1-hb-row-c .menu-item > a {
    color: #222;
}

li#menu-item-5543 a {
    color: #fff;
}

li#menu-item-5543 {
    margin-left: 20px;
}

.g1-hb-row-c .g1-drop-toggle, .g1-hb-row-c .g1-socials-item-link {
    color: #ffffff;
    color: #222;
}

li#menu-item-8483 a {
	color: #fff;
}

li#menu-item-6924 a {
	color: #fff;
}

.g1-bin-3 .g1-drop {
    margin-right: 0;
    margin-left: 15px;
}

.home li.g1-collection-item article .entry-featured-media {
    box-shadow: 0 2px 20px -6px 
    rgba(0,0,0,.2);
}

@media (min-width: 992px) {
	.g1-hb-row-normal .g1-id {
    margin-top: 0 !important;
    margin-bottom: 0 !important;
}

#page .g1-quick-nav-menu>.menu-item a {
    display: flex;
    line-height: 35px;
}

#page .g1-quick-nav-short .menu-item .entry-flag {
    margin-right: 10px;
}
	#page .g1-quick-nav-menu>.menu-item {
    margin: 0 !important;
}
}

.g1-dm-button .g1-button {
    text-indent: 40px !important;
}
.g1-hb-row-c .menu-item > a {
    color: #fdfdfd !important;
}
.g1-hb-row .sub-menu .menu-item > a {
    color: black !important;
}
li#menu-item-14524 {
    background: black;
}
.premiumdownload .g1-button {
    background: limegreen;
    border-color: limegreen;
    width: 100%;
    text-shadow: 1px 1px 2px rgba(0,0,0,.3);
}		</style>
		<noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><noscript><style id="rocket-lazyload-nojs-css">.rll-youtube-player, [data-lazy-src]{display:none !important;}</style></noscript></head>

<body data-rsssl=1 class="error404 wp-embed-responsive snax-hoverable g1-layout-stretched g1-hoverable g1-has-mobile-logo g1-sidebar-normal wpb-js-composer js-comp-ver-6.9.0 vc_responsive" itemscope="" itemtype="http://schema.org/WebPage" >

<div class="g1-body-inner">

	<div id="page">
		

		

					<div class="g1-row g1-row-layout-page g1-hb-row g1-hb-row-normal g1-hb-row-a g1-hb-row-1 g1-hb-boxed g1-hb-sticky-off g1-hb-shadow-off">
			<div class="g1-row-inner">
				<div class="g1-column g1-dropable">
											<div class="g1-bin-1 g1-bin-grow-off">
							<div class="g1-bin g1-bin-align-left">
																	<!-- BEGIN .g1-secondary-nav -->
<nav id="g1-secondary-nav" class="g1-secondary-nav"><ul id="g1-secondary-nav-menu" class="g1-secondary-nav-menu g1-menu-h"><li id="menu-item-8502" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-g1-standard menu-item-8502"><a href="https://html.design/convert-psd-design-html-css/">Convert PSD Design to HTML</a></li>
<li id="menu-item-8504" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-g1-standard menu-item-8504"><a href="https://html.design/html-to-wordpress-cms/">HTML to WordPress CMS</a></li>
<li id="menu-item-8505" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-g1-standard menu-item-8505"><a href="https://hostmileage.com/combo-offers">Domain + Hosting for 2.45$/Per month</a></li>
<li id="menu-item-8506" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-g1-standard menu-item-8506"><a href="https://html.design/contact/">Contact Us</a></li>
<li id="menu-item-8503" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-g1-standard menu-item-8503"><a href="https://html.design/donate/">Donate</a></li>
<li id="menu-item-12049" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-g1-standard menu-item-12049"><a href="https://html.design/manage-website">Manage Website</a></li>
</ul></nav><!-- END .g1-secondary-nav -->
															</div>
						</div>
											<div class="g1-bin-2 g1-bin-grow-off">
							<div class="g1-bin g1-bin-align-center">
															</div>
						</div>
											<div class="g1-bin-3 g1-bin-grow-off">
							<div class="g1-bin g1-bin-align-right">
															</div>
						</div>
									</div>
			</div>
			<div class="g1-row-background"></div>
		</div>
			<div class="g1-row g1-row-layout-page g1-hb-row g1-hb-row-normal g1-hb-row-b g1-hb-row-2 g1-hb-boxed g1-hb-sticky-off g1-hb-shadow-off">
			<div class="g1-row-inner">
				<div class="g1-column g1-dropable">
											<div class="g1-bin-1 g1-bin-grow-off">
							<div class="g1-bin g1-bin-align-left">
																	<div class="g1-id g1-id-desktop">
			<p class="g1-mega g1-mega-1st site-title">
	
			<a class="g1-logo-wrapper"
			   href="https://html.design/" rel="home">
									<picture class="g1-logo g1-logo-default">
						<source media="(min-width: 1025px)" srcset="https://html.design/wp-content/uploads/2019/04/logo-html-design-2.png 2x,https://html.design/wp-content/uploads/2019/04/logo-html-design-2.png 1x">
						<source media="(max-width: 1024px)" srcset="data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20viewBox%3D%270%200%20300%2050%27%2F%3E">
						<img
							src="https://html.design/wp-content/uploads/2019/04/logo-html-design-2.png"
							width="300"
							height="50"
							alt="HTML Design" />
					</picture>

												</a>

			</p>
	
            <script>
            try {
                if ( localStorage.getItem(skinItemId ) ) {
                    var _g1;
                    _g1 = document.getElementById('g1-logo-inverted-img');
                    _g1.classList.remove('lazyload');
                    _g1.setAttribute('src', _g1.getAttribute('data-src') );

                    _g1 = document.getElementById('g1-logo-inverted-source');
                    _g1.setAttribute('srcset', _g1.getAttribute('data-srcset'));
                }
            } catch(e) {}
        </script>
    
			<p class="g1-delta g1-delta-3rd site-description"></p>
	</div>															</div>
						</div>
											<div class="g1-bin-2 g1-bin-grow-off">
							<div class="g1-bin g1-bin-align-center">
															</div>
						</div>
											<div class="g1-bin-3 g1-bin-grow-off">
							<div class="g1-bin g1-bin-align-right">
																		<nav class="g1-quick-nav g1-quick-nav-short">
		<ul class="g1-quick-nav-menu">
															<li class="menu-item menu-item-type-g1-latest ">
						<a href="https://html.design/blog/">
							<span class="entry-flag entry-flag-latest"></span>
							Blog						</a>
					</li>
													<li class="menu-item menu-item-type-g1-popular ">
						<a href="https://html.design/popular/">
							<span class="entry-flag entry-flag-popular"></span>
							Popular						</a>
					</li>
													<li class="menu-item menu-item-type-g1-hot ">
						<a href="https://html.design/hot/">
							<span class="entry-flag entry-flag-hot"></span>
							Hot						</a>
					</li>
													<li class="menu-item menu-item-type-g1-trending ">
						<a href="https://html.design/trending/">
							<span class="entry-flag entry-flag-trending"></span>
							Trending						</a>
					</li>
									</ul>
	</nav>
															</div>
						</div>
									</div>
			</div>
			<div class="g1-row-background"></div>
		</div>
			<div class="g1-row g1-row-layout-page g1-hb-row g1-hb-row-normal g1-hb-row-c g1-hb-row-3 g1-hb-boxed g1-hb-sticky-off g1-hb-shadow-off">
			<div class="g1-row-inner">
				<div class="g1-column g1-dropable">
											<div class="g1-bin-1 g1-bin-grow-off">
							<div class="g1-bin g1-bin-align-left">
																	<!-- BEGIN .g1-primary-nav -->
<nav id="g1-primary-nav" class="g1-primary-nav"><ul id="g1-primary-nav-menu" class="g1-primary-nav-menu g1-menu-h"><li id="menu-item-14593" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-g1-standard menu-item-14593"><a href="https://html.design/premium/">Premium</a></li>
<li id="menu-item-5415" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-g1-standard menu-item-5415"><a href="https://html.design/psd-templates/">PSD</a></li>
<li id="menu-item-5398" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-g1-standard menu-item-5398"><a href="https://html.design/ecommerce-template/">Ecommerce</a></li>
<li id="menu-item-5427" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-g1-standard menu-item-5427"><a href="#">Categories</a>
<ul class="sub-menu">
	<li id="menu-item-5385" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5385"><a href="https://html.design/admin-dashboard-templates/">Admin Dashboard</a></li>
	<li id="menu-item-5408" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5408"><a href="https://html.design/lifestyle-fashion-templates/">Lifestyle</a></li>
	<li id="menu-item-5389" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5389"><a href="https://html.design/beauty-spa-templates/">Beauty and Spa</a></li>
	<li id="menu-item-5423" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5423"><a href="https://html.design/web-elements/">Web Elements</a></li>
	<li id="menu-item-5405" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5405"><a href="https://html.design/hotels-restaurant-templates/">Hotel and Restaurant</a></li>
	<li id="menu-item-5388" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5388"><a href="https://html.design/basic-templates/">Basic Templates</a></li>
	<li id="menu-item-5407" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5407"><a href="https://html.design/interior-furniture-templates/">Interior and Furniture</a></li>
	<li id="menu-item-5387" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5387"><a href="https://html.design/autos-transportation-templates/">Autos &amp; Transportation</a></li>
	<li id="menu-item-5386" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5386"><a href="https://html.design/animal-pet-templates/">Animal &amp; Pet</a></li>
	<li id="menu-item-5396" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5396"><a href="https://html.design/classifieds-ads-templates/">Classifieds Ads</a></li>
	<li id="menu-item-5399" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5399"><a href="https://html.design/education-templates/">Education</a></li>
	<li id="menu-item-5406" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5406"><a href="https://html.design/industrial-templates/">Industrial</a></li>
	<li id="menu-item-5393" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5393"><a href="https://html.design/blogging-templates/">Blogging Templates</a></li>
	<li id="menu-item-5401" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5401"><a href="https://html.design/entertainment-templates/">Entertainment</a></li>
	<li id="menu-item-5402" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5402"><a href="https://html.design/error-page-templates/">Error Page</a></li>
	<li id="menu-item-5404" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5404"><a href="https://html.design/game-sports-templates/">Game &amp; Sports</a></li>
	<li id="menu-item-5409" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5409"><a href="https://html.design/maintenance-service-templates/">Maintenance &amp; Service</a></li>
	<li id="menu-item-5403" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5403"><a href="https://html.design/farm-agriculture-templates/">Farm &amp; Agriculture</a></li>
	<li id="menu-item-5412" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5412"><a href="https://html.design/mobile-app-templates/">Mobile App</a></li>
	<li id="menu-item-5411" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5411"><a href="https://html.design/medical-hospital-templates/">Medical Hospital</a></li>
	<li id="menu-item-5410" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5410"><a href="https://html.design/marriage-wedding-templates/">Marraige &amp; Wedding</a></li>
	<li id="menu-item-5414" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5414"><a href="https://html.design/photography-templates/">Photography</a></li>
	<li id="menu-item-5413" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5413"><a href="https://html.design/personal-website-templates/">Personal Website</a></li>
	<li id="menu-item-5422" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5422"><a href="https://html.design/web-agency-templates/">Web Agency</a></li>
	<li id="menu-item-5416" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5416"><a href="https://html.design/real-estates-builders-templates/">Real Estates &amp; Builders</a></li>
	<li id="menu-item-5418" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5418"><a href="https://html.design/travel-templates/">Travel Templates</a></li>
	<li id="menu-item-5420" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5420"><a href="https://html.design/under-construction-templates/">Under Construction Template</a></li>
	<li id="menu-item-5421" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5421"><a href="https://html.design/video-audio-templates/">Video &amp; Audio</a></li>
	<li id="menu-item-5424" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5424"><a href="https://html.design/web-hosting-templates/">Web Hosting Templates</a></li>
</ul>
</li>
<li id="menu-item-5543" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-g1-standard menu-item-5543"><a href="https://html.design/convert-psd-design-html-css/">HTML Service</a></li>
<li id="menu-item-8483" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-g1-standard menu-item-8483"><a href="https://html.design/html-to-wordpress-cms/">WP Service</a></li>
<li id="menu-item-14524" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-g1-standard menu-item-14524"><a href="https://html.design/register/">Membership</a></li>
<li id="menu-item-14806" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-g1-standard menu-item-14806"><a href="https://html.design/advertising/">Advertising</a></li>
</ul></nav><!-- END .g1-primary-nav -->
															</div>
						</div>
											<div class="g1-bin-2 g1-bin-grow-off">
							<div class="g1-bin g1-bin-align-center">
															</div>
						</div>
											<div class="g1-bin-3 g1-bin-grow-off">
							<div class="g1-bin g1-bin-align-right">
																		<div class="g1-drop g1-drop-with-anim g1-drop-the-socials g1-drop-l g1-drop-icon ">
		<a class="g1-drop-toggle" href="#" title="Follow us">
			<span class="g1-drop-toggle-icon"></span><span class="g1-drop-toggle-text">Follow us</span>
			<span class="g1-drop-toggle-arrow"></span>
		</a>
		<div class="g1-drop-content">
			<ul id="g1-social-icons-1" class="g1-socials-items g1-socials-items-tpl-grid">
			<li class="g1-socials-item g1-socials-item-facebook">
	   <a class="g1-socials-item-link" href="https://facebook.com/htmldotdesign" target="_blank" rel="noopener">
		   <span class="g1-socials-item-icon g1-socials-item-icon-48 g1-socials-item-icon-text g1-socials-item-icon-facebook"></span>
		   <span class="g1-socials-item-tooltip">
			   <span class="g1-socials-item-tooltip-inner">facebook</span>
		   </span>
	   </a>
	</li>
			<li class="g1-socials-item g1-socials-item-twitter">
	   <a class="g1-socials-item-link" href="https://twitter.com/htmldotdesign" target="_blank" rel="noopener">
		   <span class="g1-socials-item-icon g1-socials-item-icon-48 g1-socials-item-icon-text g1-socials-item-icon-twitter"></span>
		   <span class="g1-socials-item-tooltip">
			   <span class="g1-socials-item-tooltip-inner">twitter</span>
		   </span>
	   </a>
	</li>
			<li class="g1-socials-item g1-socials-item-instagram">
	   <a class="g1-socials-item-link" href="https://instagram.com/htmltemplatedesign/" target="_blank" rel="noopener">
		   <span class="g1-socials-item-icon g1-socials-item-icon-48 g1-socials-item-icon-text g1-socials-item-icon-instagram"></span>
		   <span class="g1-socials-item-tooltip">
			   <span class="g1-socials-item-tooltip-inner">instagram</span>
		   </span>
	   </a>
	</li>
			<li class="g1-socials-item g1-socials-item-pinterest">
	   <a class="g1-socials-item-link" href="https://html.design" target="_blank" rel="noopener">
		   <span class="g1-socials-item-icon g1-socials-item-icon-48 g1-socials-item-icon-text g1-socials-item-icon-pinterest"></span>
		   <span class="g1-socials-item-tooltip">
			   <span class="g1-socials-item-tooltip-inner">pinterest</span>
		   </span>
	   </a>
	</li>
	</ul>
		</div>
	</div>
																		<div class="g1-drop g1-drop-with-anim g1-drop-before g1-drop-the-search  g1-drop-l g1-drop-icon ">
		<a class="g1-drop-toggle" href="https://html.design/?s=">
			<span class="g1-drop-toggle-icon"></span><span class="g1-drop-toggle-text">Search</span>
			<span class="g1-drop-toggle-arrow"></span>
		</a>
		<div class="g1-drop-content">
			

<div role="search" class="search-form-wrapper">
	<form method="get"
	      class="g1-searchform-tpl-default g1-searchform-ajax search-form"
	      action="https://html.design/">
		<label>
			<span class="screen-reader-text">Search for:</span>
			<input type="search" class="search-field"
			       placeholder="Search &hellip;"
			       value="" name="s"
			       title="Search for:" />
		</label>
		<button class="search-submit">Search</button>
	</form>

			<div class="g1-searches g1-searches-ajax"></div>
	</div>
		</div>
	</div>
																	<nav class="g1-drop g1-drop-with-anim g1-drop-before g1-drop-the-user  g1-drop-l g1-drop-icon ">


	<a class="g1-drop-toggle snax-login-required" href="#">
		<span class="g1-drop-toggle-icon"></span><span class="g1-drop-toggle-text">Login</span>
		<span class="g1-drop-toggle-arrow"></span>
	</a>

	
	
	</nav>
																																																		</div>
						</div>
									</div>
			</div>
			<div class="g1-row-background"></div>
		</div>
				<div class="g1-row g1-row-layout-page g1-hb-row g1-hb-row-mobile g1-hb-row-a g1-hb-row-1 g1-hb-boxed g1-hb-sticky-off g1-hb-shadow-off">
			<div class="g1-row-inner">
				<div class="g1-column g1-dropable">
											<div class="g1-bin-1 g1-bin-grow-off">
							<div class="g1-bin g1-bin-align-left">
															</div>
						</div>
											<div class="g1-bin-2 g1-bin-grow-on">
							<div class="g1-bin g1-bin-align-center">
															</div>
						</div>
											<div class="g1-bin-3 g1-bin-grow-off">
							<div class="g1-bin g1-bin-align-right">
															</div>
						</div>
									</div>
			</div>
			<div class="g1-row-background"></div>
		</div>
			<div class="g1-row g1-row-layout-page g1-hb-row g1-hb-row-mobile g1-hb-row-b g1-hb-row-2 g1-hb-boxed g1-hb-sticky-off g1-hb-shadow-off">
			<div class="g1-row-inner">
				<div class="g1-column g1-dropable">
											<div class="g1-bin-1 g1-bin-grow-off">
							<div class="g1-bin g1-bin-align-left">
															</div>
						</div>
											<div class="g1-bin-2 g1-bin-grow-on">
							<div class="g1-bin g1-bin-align-center">
																		<nav class="g1-quick-nav g1-quick-nav-short">
		<ul class="g1-quick-nav-menu">
															<li class="menu-item menu-item-type-g1-latest ">
						<a href="https://html.design/blog/">
							<span class="entry-flag entry-flag-latest"></span>
							Blog						</a>
					</li>
													<li class="menu-item menu-item-type-g1-popular ">
						<a href="https://html.design/popular/">
							<span class="entry-flag entry-flag-popular"></span>
							Popular						</a>
					</li>
													<li class="menu-item menu-item-type-g1-hot ">
						<a href="https://html.design/hot/">
							<span class="entry-flag entry-flag-hot"></span>
							Hot						</a>
					</li>
													<li class="menu-item menu-item-type-g1-trending ">
						<a href="https://html.design/trending/">
							<span class="entry-flag entry-flag-trending"></span>
							Trending						</a>
					</li>
									</ul>
	</nav>
															</div>
						</div>
											<div class="g1-bin-3 g1-bin-grow-off">
							<div class="g1-bin g1-bin-align-right">
															</div>
						</div>
									</div>
			</div>
			<div class="g1-row-background"></div>
		</div>
			<div class="g1-row g1-row-layout-page g1-hb-row g1-hb-row-mobile g1-hb-row-c g1-hb-row-3 g1-hb-boxed g1-hb-sticky-off g1-hb-shadow-off">
			<div class="g1-row-inner">
				<div class="g1-column g1-dropable">
											<div class="g1-bin-1 g1-bin-grow-off">
							<div class="g1-bin g1-bin-align-left">
																		<a class="g1-hamburger g1-hamburger-show  " href="#">
		<span class="g1-hamburger-icon"></span>
			<span class="g1-hamburger-label
			g1-hamburger-label-hidden			">Menu</span>
	</a>
															</div>
						</div>
											<div class="g1-bin-2 g1-bin-grow-off">
							<div class="g1-bin g1-bin-align-center">
															</div>
						</div>
											<div class="g1-bin-3 g1-bin-grow-off">
							<div class="g1-bin g1-bin-align-right">
																		<div class="g1-drop g1-drop-with-anim g1-drop-the-socials g1-drop-l g1-drop-icon ">
		<a class="g1-drop-toggle" href="#" title="Follow us">
			<span class="g1-drop-toggle-icon"></span><span class="g1-drop-toggle-text">Follow us</span>
			<span class="g1-drop-toggle-arrow"></span>
		</a>
		<div class="g1-drop-content">
			<ul id="g1-social-icons-2" class="g1-socials-items g1-socials-items-tpl-grid">
			<li class="g1-socials-item g1-socials-item-facebook">
	   <a class="g1-socials-item-link" href="https://facebook.com/htmldotdesign" target="_blank" rel="noopener">
		   <span class="g1-socials-item-icon g1-socials-item-icon-48 g1-socials-item-icon-text g1-socials-item-icon-facebook"></span>
		   <span class="g1-socials-item-tooltip">
			   <span class="g1-socials-item-tooltip-inner">facebook</span>
		   </span>
	   </a>
	</li>
			<li class="g1-socials-item g1-socials-item-twitter">
	   <a class="g1-socials-item-link" href="https://twitter.com/htmldotdesign" target="_blank" rel="noopener">
		   <span class="g1-socials-item-icon g1-socials-item-icon-48 g1-socials-item-icon-text g1-socials-item-icon-twitter"></span>
		   <span class="g1-socials-item-tooltip">
			   <span class="g1-socials-item-tooltip-inner">twitter</span>
		   </span>
	   </a>
	</li>
			<li class="g1-socials-item g1-socials-item-instagram">
	   <a class="g1-socials-item-link" href="https://instagram.com/htmltemplatedesign/" target="_blank" rel="noopener">
		   <span class="g1-socials-item-icon g1-socials-item-icon-48 g1-socials-item-icon-text g1-socials-item-icon-instagram"></span>
		   <span class="g1-socials-item-tooltip">
			   <span class="g1-socials-item-tooltip-inner">instagram</span>
		   </span>
	   </a>
	</li>
			<li class="g1-socials-item g1-socials-item-pinterest">
	   <a class="g1-socials-item-link" href="https://html.design" target="_blank" rel="noopener">
		   <span class="g1-socials-item-icon g1-socials-item-icon-48 g1-socials-item-icon-text g1-socials-item-icon-pinterest"></span>
		   <span class="g1-socials-item-tooltip">
			   <span class="g1-socials-item-tooltip-inner">pinterest</span>
		   </span>
	   </a>
	</li>
	</ul>
		</div>
	</div>
																		<div class="g1-drop g1-drop-with-anim g1-drop-before g1-drop-the-search  g1-drop-l g1-drop-icon ">
		<a class="g1-drop-toggle" href="https://html.design/?s=">
			<span class="g1-drop-toggle-icon"></span><span class="g1-drop-toggle-text">Search</span>
			<span class="g1-drop-toggle-arrow"></span>
		</a>
		<div class="g1-drop-content">
			

<div role="search" class="search-form-wrapper">
	<form method="get"
	      class="g1-searchform-tpl-default g1-searchform-ajax search-form"
	      action="https://html.design/">
		<label>
			<span class="screen-reader-text">Search for:</span>
			<input type="search" class="search-field"
			       placeholder="Search &hellip;"
			       value="" name="s"
			       title="Search for:" />
		</label>
		<button class="search-submit">Search</button>
	</form>

			<div class="g1-searches g1-searches-ajax"></div>
	</div>
		</div>
	</div>
																																</div>
						</div>
									</div>
			</div>
			<div class="g1-row-background"></div>
		</div>
	
		
		



		

	<div id="primary" class="g1-primary-max">
		<div id="content" role="main">

			<article id="post-0">
				
<header class="page-header page-header-01 g1-row g1-row-layout-page">
	<div class="g1-row-inner">
		<div class="g1-column">
			
							<h1 class="g1-alpha g1-alpha-2nd page-title">Ooops, sorry! We couldn't find it</h1>
			
							<h2 class="g1-delta g1-delta-3rd page-subtitle">You have requested a page or file which doesn't exist</h2>
					</div>
	</div>
	<div class="g1-row-background">
	</div>
</header>
				<div class="g1-row g1-row-layout-page g1-row-padding-l entry-content">
					<div class="g1-row-inner">

						<div class="g1-column g1-column-1of3 g1-404-search ">
							<i class="g1-404-icon"></i>
							<h2 class="g1-delta g1-delta-2nd"><span>Search Our Website</span></h2>							

<div role="search" class="search-form-wrapper">
	<form method="get"
	      class="g1-searchform-tpl-default g1-searchform-ajax search-form"
	      action="https://html.design/">
		<label>
			<span class="screen-reader-text">Search for:</span>
			<input type="search" class="search-field"
			       placeholder="Search &hellip;"
			       value="" name="s"
			       title="Search for:" />
		</label>
		<button class="search-submit">Search</button>
	</form>

			<div class="g1-searches g1-searches-ajax"></div>
	</div>
						</div><!-- .g1-column -->

						<div class="g1-column g1-column-1of3 g1-404-report">
							<i class="g1-404-icon"></i>
							<h2 class="g1-delta g1-delta-2nd"><span>Report a Problem</span></h2>							<p>Please write some descriptive information about your problem, and email our <a href="/cdn-cgi/l/email-protection#0421323c22273535323f222735343d3f21326721323021326221333022273534343f617721323d2132336a22273432303f22273534373f222735343d3f21323521323d222735343c3f22273430323f676b69">webmaster</a>.</p>
						</div><!-- .g1-column -->

						<div class="g1-column g1-column-1of3 g1-404-back">
							<i class="g1-404-icon"></i>
							<h2 class="g1-delta g1-delta-2nd"><span>Back to the Homepage</span></h2>							<p>You can also <a href="https://html.design">go back to the homepage</a> and start browsing from there.</p>
						</div>
					</div>

					<div class="g1-row-background">
					</div>
				</div><!-- .entry-content -->

			</article><!-- #post-0 -->

		</div><!-- #content -->
	</div><!-- #primary -->


	
<div class=" g1-prefooter g1-prefooter-3cols g1-row g1-row-layout-page">
	<div class="g1-row-inner">

		<div class="g1-column g1-column-1of3">
			<aside id="text-2" class="widget widget_text"><header><h2 class="g1-delta g1-delta-2nd widgettitle"><span>Disclaimer</span></h2></header>			<div class="textwidget"><p>We are group of people who love to share FREE HTML templates, trying to make a community hub for all types of Category Templates so that you can use for your Website.</p>
</div>
		</aside><aside id="g1_socials-3" class="widget widget_g1_socials"><header><h2 class="g1-delta g1-delta-2nd widgettitle"><span>Follow us</span></h2></header><ul id="g1-social-icons-3" class="g1-socials-items g1-socials-items-tpl-grid">
			<li class="g1-socials-item g1-socials-item-facebook">
	   <a class="g1-socials-item-link" href="https://facebook.com/htmldotdesign" target="_blank" rel="noopener">
		   <span class="g1-socials-item-icon g1-socials-item-icon-48 g1-socials-item-icon-text g1-socials-item-icon-facebook"></span>
		   <span class="g1-socials-item-tooltip">
			   <span class="g1-socials-item-tooltip-inner">facebook</span>
		   </span>
	   </a>
	</li>
			<li class="g1-socials-item g1-socials-item-twitter">
	   <a class="g1-socials-item-link" href="https://twitter.com/htmldotdesign" target="_blank" rel="noopener">
		   <span class="g1-socials-item-icon g1-socials-item-icon-48 g1-socials-item-icon-text g1-socials-item-icon-twitter"></span>
		   <span class="g1-socials-item-tooltip">
			   <span class="g1-socials-item-tooltip-inner">twitter</span>
		   </span>
	   </a>
	</li>
			<li class="g1-socials-item g1-socials-item-instagram">
	   <a class="g1-socials-item-link" href="https://instagram.com/htmltemplatedesign/" target="_blank" rel="noopener">
		   <span class="g1-socials-item-icon g1-socials-item-icon-48 g1-socials-item-icon-text g1-socials-item-icon-instagram"></span>
		   <span class="g1-socials-item-tooltip">
			   <span class="g1-socials-item-tooltip-inner">instagram</span>
		   </span>
	   </a>
	</li>
			<li class="g1-socials-item g1-socials-item-pinterest">
	   <a class="g1-socials-item-link" href="https://html.design" target="_blank" rel="noopener">
		   <span class="g1-socials-item-icon g1-socials-item-icon-48 g1-socials-item-icon-text g1-socials-item-icon-pinterest"></span>
		   <span class="g1-socials-item-tooltip">
			   <span class="g1-socials-item-tooltip-inner">pinterest</span>
		   </span>
	   </a>
	</li>
	</ul>
</aside><aside id="text-3" class="widget widget_text">			<div class="textwidget"><p>Images being used are not sold or distributed it just for showcase. We respect all copyright issue, please do all email us if anything suspects you.</p>
</div>
		</aside>		</div>

		<div class="g1-column g1-column-1of3">
			<aside id="mc4wp_form_widget-9" class="widget widget_mc4wp_form_widget"><header><h2 class="g1-delta g1-delta-2nd widgettitle"><span>Newsletter</span></h2></header><script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>(function() {
	window.mc4wp = window.mc4wp || {
		listeners: [],
		forms: {
			on: function(evt, cb) {
				window.mc4wp.listeners.push(
					{
						event   : evt,
						callback: cb
					}
				);
			}
		}
	}
})();
</script><!-- Mailchimp for WordPress v4.8.10 - https://wordpress.org/plugins/mailchimp-for-wp/ --><form id="mc4wp-form-1" class="mc4wp-form mc4wp-form-4468" method="post" data-id="4468" data-name="Default sign-up form" ><p class="g1-alpha g1-alpha-1st">Want more stuff like this?</p><div class="mc4wp-form-fields"><p>
	<label>Email address: </label>
	<input type="email" name="EMAIL" placeholder="Your email address" required />
</p>

<p>
	<input type="submit" value="Sign up" />
</p></div><label style="display: none !important;">Leave this field empty if you're human: <input type="text" name="_mc4wp_honeypot" value="" tabindex="-1" autocomplete="off" /></label><input type="hidden" name="_mc4wp_timestamp" value="1663819132" /><input type="hidden" name="_mc4wp_form_id" value="4468" /><input type="hidden" name="_mc4wp_form_element_id" value="mc4wp-form-1" /><div class="mc4wp-response"></div><p class="g1-meta g1-newsletter-privacy">Don&#039;t worry, we don&#039;t spam</p></form><!-- / Mailchimp for WordPress Plugin --></aside>		</div>

		<div class="g1-column g1-column-1of3">
			<aside id="bimber_widget_posts-6" class="widget widget_bimber_widget_posts"><header><h2 class="g1-delta g1-delta-2nd widgettitle"><span>Most Downloaded</span></h2></header>			<div id="g1-widget-posts-1"
			     class=" g1-widget-posts">
									<div class="g1-collection">
	
			<div class="g1-collection-viewport">
			<ul class="g1-collection-items">
									<li class="g1-collection-item">
						
<article class="entry-tpl-listxxs post-10529 post type-post status-publish format-standard has-post-thumbnail category-animal-pet-templates">
	<div class="entry-featured-media " ><a title="Birdim &#8211; Bird Care HTML Template" class="g1-frame" href="https://html.design/download/birdim-bird-care-html-template/"><div class="g1-frame-inner"><img data-expand="600" width="90" height="67" src="data:image/svg+xml;charset=utf-8,%3Csvg xmlns%3D&#039;http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg&#039; viewBox%3D&#039;0 0 90 67&#039;%2F%3E" data-src="https://html.design/wp-content/uploads/2020/01/birdim-90x67.jpg" class="lazyload attachment-bimber-list-xxs size-bimber-list-xxs wp-post-image" alt="Bird Care PSD Template Free Download" loading="lazy" data-srcset="https://html.design/wp-content/uploads/2020/01/birdim-90x67.jpg 90w, https://html.design/wp-content/uploads/2020/01/birdim-192x144.jpg 192w, https://html.design/wp-content/uploads/2020/01/birdim-384x288.jpg 384w, https://html.design/wp-content/uploads/2020/01/birdim-180x135.jpg 180w" data-sizes="(max-width: 90px) 100vw, 90px" title="Birdim - Bird Care HTML Template 1"><span class="g1-frame-icon g1-frame-icon-"></span></div></a></div>
	<header class="entry-header">
		<h3 class="g1-epsilon g1-epsilon-1st entry-title"><a href="https://html.design/download/birdim-bird-care-html-template/" rel="bookmark">Birdim &#8211; Bird Care HTML Template</a></h3>	</header>

	</article>
					</li>
									<li class="g1-collection-item">
						
<article class="entry-tpl-listxxs post-11599 post type-post status-publish format-standard has-post-thumbnail category-game-sports-templates category-psd-templates">
	<div class="entry-featured-media " ><a title="Faraado &#8211; Car Game PSD Template" class="g1-frame" href="https://html.design/download/faraado-car-game-psd-template/"><div class="g1-frame-inner"><img data-expand="600" width="90" height="67" src="data:image/svg+xml;charset=utf-8,%3Csvg xmlns%3D&#039;http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg&#039; viewBox%3D&#039;0 0 90 67&#039;%2F%3E" data-src="https://html.design/wp-content/uploads/2020/04/faraado-90x67.jpg" class="lazyload attachment-bimber-list-xxs size-bimber-list-xxs wp-post-image" alt="faraado" loading="lazy" data-srcset="https://html.design/wp-content/uploads/2020/04/faraado-90x67.jpg 90w, https://html.design/wp-content/uploads/2020/04/faraado-192x144.jpg 192w, https://html.design/wp-content/uploads/2020/04/faraado-384x288.jpg 384w, https://html.design/wp-content/uploads/2020/04/faraado-180x135.jpg 180w" data-sizes="(max-width: 90px) 100vw, 90px" title="Faraado - Car Game PSD Template 2"><span class="g1-frame-icon g1-frame-icon-"></span></div></a></div>
	<header class="entry-header">
		<h3 class="g1-epsilon g1-epsilon-1st entry-title"><a href="https://html.design/download/faraado-car-game-psd-template/" rel="bookmark">Faraado &#8211; Car Game PSD Template</a></h3>	</header>

	</article>
					</li>
									<li class="g1-collection-item">
						
<article class="entry-tpl-listxxs post-11606 post type-post status-publish format-standard has-post-thumbnail category-basic-templates category-farm-agriculture-templates">
	<div class="entry-featured-media " ><a title="Farmfund &#8211; Retailers Website Template" class="g1-frame" href="https://html.design/download/retailers-website-template/"><div class="g1-frame-inner"><img data-expand="600" width="90" height="67" src="data:image/svg+xml;charset=utf-8,%3Csvg xmlns%3D&#039;http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg&#039; viewBox%3D&#039;0 0 90 67&#039;%2F%3E" data-src="https://html.design/wp-content/uploads/2020/04/farmfund-90x67.jpg" class="lazyload attachment-bimber-list-xxs size-bimber-list-xxs wp-post-image" alt="farmfund" loading="lazy" data-srcset="https://html.design/wp-content/uploads/2020/04/farmfund-90x67.jpg 90w, https://html.design/wp-content/uploads/2020/04/farmfund-192x144.jpg 192w, https://html.design/wp-content/uploads/2020/04/farmfund-384x288.jpg 384w, https://html.design/wp-content/uploads/2020/04/farmfund-180x135.jpg 180w" data-sizes="(max-width: 90px) 100vw, 90px" title="Farmfund - Retailers Website Template 3"><span class="g1-frame-icon g1-frame-icon-"></span></div></a></div>
	<header class="entry-header">
		<h3 class="g1-epsilon g1-epsilon-1st entry-title"><a href="https://html.design/download/retailers-website-template/" rel="bookmark">Farmfund &#8211; Retailers Website Template</a></h3>	</header>

	</article>
					</li>
									<li class="g1-collection-item">
						
<article class="entry-tpl-listxxs post-11481 post type-post status-publish format-standard has-post-thumbnail category-marriage-wedding-templates category-psd-templates">
	<div class="entry-featured-media " ><a title="Donila &#8211; Wedding PSD Template" class="g1-frame" href="https://html.design/download/donila-wedding-psd-template/"><div class="g1-frame-inner"><img data-expand="600" width="90" height="67" src="data:image/svg+xml;charset=utf-8,%3Csvg xmlns%3D&#039;http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg&#039; viewBox%3D&#039;0 0 90 67&#039;%2F%3E" data-src="https://html.design/wp-content/uploads/2020/04/donila-90x67.jpg" class="lazyload attachment-bimber-list-xxs size-bimber-list-xxs wp-post-image" alt="Donila – Wedding Website HTML Template Free" loading="lazy" data-srcset="https://html.design/wp-content/uploads/2020/04/donila-90x67.jpg 90w, https://html.design/wp-content/uploads/2020/04/donila-192x144.jpg 192w, https://html.design/wp-content/uploads/2020/04/donila-384x288.jpg 384w, https://html.design/wp-content/uploads/2020/04/donila-180x135.jpg 180w" data-sizes="(max-width: 90px) 100vw, 90px" title="Donila - Wedding PSD Template 4"><span class="g1-frame-icon g1-frame-icon-"></span></div></a></div>
	<header class="entry-header">
		<h3 class="g1-epsilon g1-epsilon-1st entry-title"><a href="https://html.design/download/donila-wedding-psd-template/" rel="bookmark">Donila &#8211; Wedding PSD Template</a></h3>	</header>

	</article>
					</li>
							</ul>
		</div>
	</div><!-- .g1-collection -->
							</div>
			</aside>		</div>

	</div>
	<div class="g1-row-background">
		<div class="g1-row-background-media">
		</div>
	</div>
</div><!-- .g1-prefooter -->

		<div class="g1-footer g1-row g1-row-layout-page">
			<div class="g1-row-inner">
				<div class="g1-column">

					<p class="g1-footer-text">Copyright 2021 @ HTML Design</p>

					
					<nav id="g1-footer-nav" class="g1-footer-nav"><ul id="g1-footer-nav-menu" class=""><li id="menu-item-5432" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5432"><a href="https://html.design/about/">About</a></li>
<li id="menu-item-5433" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5433"><a href="https://html.design/license/">License</a></li>
<li id="menu-item-4465" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4465"><a href="https://html.design/gdpr-privacy-policy/">GDPR Privacy policy</a></li>
<li id="menu-item-5434" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5434"><a href="https://html.design/privacy-policy/">Privacy Policy</a></li>
<li id="menu-item-11904" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11904"><a href="https://html.design/advertising/">Advertising</a></li>
<li id="menu-item-4463" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4463"><a href="https://html.design/contact/">Contact Us</a></li>
</ul></nav>
					
				</div><!-- .g1-column -->
			</div>
			<div class="g1-row-background">
			</div>
		</div><!-- .g1-row -->

					<a href="#page" class="g1-back-to-top">Back to Top</a>
						</div><!-- #page -->

<div class="g1-canvas-overlay">
</div>

</div><!-- .g1-body-inner -->

<div id="g1-breakpoint-desktop">
</div>


<div class="g1-canvas g1-canvas-global g1-canvas-no-js">
	<div class="g1-canvas-inner">
		<div class="g1-canvas-content">
			<a class="g1-canvas-toggle" href="#">Close</a>

				<!-- BEGIN .g1-primary-nav -->
	<nav id="g1-canvas-primary-nav" class="g1-primary-nav"><ul id="g1-canvas-primary-nav-menu" class="g1-primary-nav-menu g1-menu-v"><li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-14593"><a href="https://html.design/premium/">Premium</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5415"><a href="https://html.design/psd-templates/">PSD</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5398"><a href="https://html.design/ecommerce-template/">Ecommerce</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-5427"><a href="#">Categories</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5385"><a href="https://html.design/admin-dashboard-templates/">Admin Dashboard</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5408"><a href="https://html.design/lifestyle-fashion-templates/">Lifestyle</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5389"><a href="https://html.design/beauty-spa-templates/">Beauty and Spa</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5423"><a href="https://html.design/web-elements/">Web Elements</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5405"><a href="https://html.design/hotels-restaurant-templates/">Hotel and Restaurant</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5388"><a href="https://html.design/basic-templates/">Basic Templates</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5407"><a href="https://html.design/interior-furniture-templates/">Interior and Furniture</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5387"><a href="https://html.design/autos-transportation-templates/">Autos &amp; Transportation</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5386"><a href="https://html.design/animal-pet-templates/">Animal &amp; Pet</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5396"><a href="https://html.design/classifieds-ads-templates/">Classifieds Ads</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5399"><a href="https://html.design/education-templates/">Education</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5406"><a href="https://html.design/industrial-templates/">Industrial</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5393"><a href="https://html.design/blogging-templates/">Blogging Templates</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5401"><a href="https://html.design/entertainment-templates/">Entertainment</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5402"><a href="https://html.design/error-page-templates/">Error Page</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5404"><a href="https://html.design/game-sports-templates/">Game &amp; Sports</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5409"><a href="https://html.design/maintenance-service-templates/">Maintenance &amp; Service</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5403"><a href="https://html.design/farm-agriculture-templates/">Farm &amp; Agriculture</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5412"><a href="https://html.design/mobile-app-templates/">Mobile App</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5411"><a href="https://html.design/medical-hospital-templates/">Medical Hospital</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5410"><a href="https://html.design/marriage-wedding-templates/">Marraige &amp; Wedding</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5414"><a href="https://html.design/photography-templates/">Photography</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5413"><a href="https://html.design/personal-website-templates/">Personal Website</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5422"><a href="https://html.design/web-agency-templates/">Web Agency</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5416"><a href="https://html.design/real-estates-builders-templates/">Real Estates &amp; Builders</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5418"><a href="https://html.design/travel-templates/">Travel Templates</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5420"><a href="https://html.design/under-construction-templates/">Under Construction Template</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5421"><a href="https://html.design/video-audio-templates/">Video &amp; Audio</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5424"><a href="https://html.design/web-hosting-templates/">Web Hosting Templates</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5543"><a href="https://html.design/convert-psd-design-html-css/">HTML Service</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-8483"><a href="https://html.design/html-to-wordpress-cms/">WP Service</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-14524"><a href="https://html.design/register/">Membership</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-14806"><a href="https://html.design/advertising/">Advertising</a></li>
</ul></nav>		<!-- END .g1-primary-nav -->
		<!-- BEGIN .g1-secondary-nav -->
	<nav id="g1-canvas-secondary-nav" class="g1-secondary-nav"><ul id="g1-canvas-secondary-nav-menu" class="g1-secondary-nav-menu g1-menu-v"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-8502"><a href="https://html.design/convert-psd-design-html-css/">Convert PSD Design to HTML</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-8504"><a href="https://html.design/html-to-wordpress-cms/">HTML to WordPress CMS</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-8505"><a href="https://hostmileage.com/combo-offers">Domain + Hosting for 2.45$/Per month</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-8506"><a href="https://html.design/contact/">Contact Us</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-8503"><a href="https://html.design/donate/">Donate</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-12049"><a href="https://html.design/manage-website">Manage Website</a></li>
</ul></nav>		<!-- END .g1-secondary-nav -->
		
			<nav class="g1-quick-nav g1-quick-nav-short">
			<ul class="g1-quick-nav-menu g1-menu g1-menu-v g1-menu-with-icons">
				
				                    						<li class="menu-item menu-item-type-g1-latest ">
							<a href="https://html.design/blog/">
								<span class="entry-flag entry-flag-latest"></span>
								Blog							</a>
						</li>
					
											<li class="menu-item menu-item-type-g1-popular ">
							<a href="https://html.design/popular/">
								<span class="entry-flag entry-flag-popular"></span>
								Popular							</a>
						</li>
					
											<li class="menu-item menu-item-type-g1-hot ">
							<a href="https://html.design/hot/">
								<span class="entry-flag entry-flag-hot"></span>
								Hot							</a>
						</li>
					
											<li class="menu-item menu-item-type-g1-trending ">
							<a href="https://html.design/trending/">
								<span class="entry-flag entry-flag-trending"></span>
								Trending							</a>
						</li>
					
							</ul>
		</nav>
	<ul id="g1-social-icons-4" class="g1-socials-items g1-socials-items-tpl-grid">
			<li class="g1-socials-item g1-socials-item-facebook">
	   <a class="g1-socials-item-link" href="https://facebook.com/htmldotdesign" target="_blank" rel="noopener">
		   <span class="g1-socials-item-icon g1-socials-item-icon-48 g1-socials-item-icon-text g1-socials-item-icon-facebook"></span>
		   <span class="g1-socials-item-tooltip">
			   <span class="g1-socials-item-tooltip-inner">facebook</span>
		   </span>
	   </a>
	</li>
			<li class="g1-socials-item g1-socials-item-twitter">
	   <a class="g1-socials-item-link" href="https://twitter.com/htmldotdesign" target="_blank" rel="noopener">
		   <span class="g1-socials-item-icon g1-socials-item-icon-48 g1-socials-item-icon-text g1-socials-item-icon-twitter"></span>
		   <span class="g1-socials-item-tooltip">
			   <span class="g1-socials-item-tooltip-inner">twitter</span>
		   </span>
	   </a>
	</li>
			<li class="g1-socials-item g1-socials-item-instagram">
	   <a class="g1-socials-item-link" href="https://instagram.com/htmltemplatedesign/" target="_blank" rel="noopener">
		   <span class="g1-socials-item-icon g1-socials-item-icon-48 g1-socials-item-icon-text g1-socials-item-icon-instagram"></span>
		   <span class="g1-socials-item-tooltip">
			   <span class="g1-socials-item-tooltip-inner">instagram</span>
		   </span>
	   </a>
	</li>
			<li class="g1-socials-item g1-socials-item-pinterest">
	   <a class="g1-socials-item-link" href="https://html.design" target="_blank" rel="noopener">
		   <span class="g1-socials-item-icon g1-socials-item-icon-48 g1-socials-item-icon-text g1-socials-item-icon-pinterest"></span>
		   <span class="g1-socials-item-tooltip">
			   <span class="g1-socials-item-tooltip-inner">pinterest</span>
		   </span>
	   </a>
	</li>
	</ul>


<div role="search" class="search-form-wrapper">
	<form method="get"
	      class="g1-searchform-tpl-default search-form"
	      action="https://html.design/">
		<label>
			<span class="screen-reader-text">Search for:</span>
			<input type="search" class="search-field"
			       placeholder="Search &hellip;"
			       value="" name="s"
			       title="Search for:" />
		</label>
		<button class="search-submit">Search</button>
	</form>

	</div>
			</div>
							<div class="g1-canvas-background">
			</div>
			</div>
</div>
<div class="wpgdprc-consent-bar wpgdprc-consent-bar--position-bottom" style="display: none;">
	<div class="wpgdprc-consent-bar__inner">
		<div class="wpgdprc-consent-bar__container">
			<div class="wpgdprc-consent-bar__content">
				<div class="wpgdprc-consent-bar__column wpgdprc-consent-bar__column--notice">
					<div class="wpgdprc-consent-bar__notice"><p>This site uses functional cookies and external scripts to improve your experience.</p>
</div>
				</div>
				<div class="wpgdprc-consent-bar__column wpgdprc-consent-bar__column--settings">
					<button type="button" class="wpgdprc-button wpgdprc-button--settings"
							data-micromodal-trigger="wpgdprc-consent-modal"
							aria-expanded="false"
							aria-haspopup="true"
					>
						My settings					</button>
				</div>
				<div class="wpgdprc-consent-bar__column wpgdprc-consent-bar__column--accept">
					<button type="button" class="wpgdprc-button wpgdprc-button--accept">
						Accept					</button>
				</div>
			</div>
		</div>
	</div>
</div>
	<style type="text/css">
		@media only screen and (max-width: 600px ) {
			.adace-hide-on-mobile{
				display:none !important;
			}
			.adace-hide-on-phone{
				display:none !important;
			}
		}
		@media only screen and (min-width: 601px  ) and  (max-width: 800px ){
			.adace-hide-on-portrait{
				display:none !important;
			}
		}
		@media only screen and (min-width: 801px  ) and  (max-width: 960px ){
			.adace-hide-on-landscape{
				display:none !important;
			}
		}
		@media only screen and (min-width: 601px  ) and  (max-width: 960px ){
			.adace-hide-on-tablet{
				display:none !important;
			}
		}
		@media only screen and (min-width: 961px  ){
			.adace-hide-on-desktop{
				display:none !important;
			}
		}
	</style>
		<div id="snax-popup-content" class="snax white-popup mfp-hide">
		
<div class="snax-login-tab snax-tab-active">

	<h2 class="g1-alpha">Log In</h2>

	
	
	
	
		
		<h4 class="snax-form-legend snax-form-legend-sign-in">Sign In</h4>

		<div class="snax-login-form">
			<form name="loginform-in-popup" id="loginform-in-popup" action="https://html.design/newadminjack/" method="post"><div class="snax-validation-error snax-login-error-message"></div><p class="login-username">
				<label for="user_login">Username or Email Address</label>
				<input type="text" name="log" id="user_login" autocomplete="username" class="input" value="" size="20" />
			</p><p class="login-password">
				<label for="user_pass">Password</label>
				<input type="password" name="pwd" id="user_pass" autocomplete="current-password" class="input" value="" size="20" />
			</p><div id="snax-login-recaptcha"></div><p class="login-remember"><label><input name="rememberme" type="checkbox" id="rememberme" value="forever" /> Remember Me</label></p><p class="login-submit">
				<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary" value="Log In" />
				<input type="hidden" name="redirect_to" value="https://html.design/demo/sunshine/audins.js" />
			</p></form>		</div>

		<a class="snax-link-forgot-pass" href="https://html.design/?snax_login_popup=forgot_password">Forgot password?</a>

		
	
	
</div>

<div class="snax-forgot-pass-tab snax-tab-inactive">

	<h2 class="g1-alpha g1-alpha-2nd">Forgot password?</h2>

	<p>
		Enter your account data and we will send you a link to reset your password.	</p>

	
	<div class="snax-forgot-pass-form">
		<form name="lostpasswordform" id="lostpasswordform" action="https://html.design/newadminjack/?action=lostpassword" method="post">
			<div class="snax-validation-error snax-forgot-pass-error-message"></div>
			<div class="snax-validation-error snax-forgot-pass-success-message"></div>
			<p class="forgot-username">
				<label for="user_login">Username or Email Address</label>
				<input type="text" name="user_login" id="forgot-user_login" class="input" value="" size="20" placeholder="Username or Email Address" />
			</p>
			
			<input type="hidden" name="redirect_to" value="https://html.design/demo/sunshine/audins.js" />
			<p class="forgot-submit">
				<input type="submit" name="wp-submit" id="forgot-wp-submit" class="button button-primary button-large" value="Reset Password" />
			</p>

			<a href="#" class="snax-back-to-login-tab">Back to Login</a>
		</form>
	</div>

	
</div>

<div class="snax-reset-tab snax-tab-inactive">

	<div class="snax-reset-pass-form">
		<h2>Your password reset link appears to be invalid or expired.</h2>
	</div>


</div>

<div class="snax-gdpr-tab snax-tab-inactive">

	<h2 class="g1-alpha">Log in</h2>

	<h3 class="g1-delta">Privacy Policy</h3>

	<p>	To use social login you have to agree with the storage and handling of your data by this website. <a href="https://html.design/privacy-policy/">Privacy Policy</a></p>

	<a class="g1-button g1-button-l g1-button-wide g1-button-solid snax-login-gdpr-accept" href="#">Accept</a>

</div>
	</div>
	<div class="snax snax-notifications snax-notifications-off">
	<div class="snax-notification">
		<button class="snax-notification-close">Close</button>
		<p class="snax-notification-text"></p>
	</div>
</div><div id="snax-popup-add-to-collection" class="snax white-popup mfp-hide">
	<h2>Add to Collection</h2>

	<div class="snax-add-to-collection"><!--  .snax-add-to-collection-loading -->
		<form class="snax-form-collection-search">
			<label>
				Add new or search				<input name="snax-collection-search" type="search" placeholder="Add new&hellip;" autocomplete="off" />
			</label>
			<input name="snax-collection-save" type="submit" value="Save" disabled="disabled" />
		</form>
		<div class="snax-collections snax-collections-tpl-listxs">
			<ul class="snax-collections-items">
				<li class="snax-collections-item">
					<div class="snax-collection snax-collection-tpl-listxs snax-collection-public">
						<p class="snax-collection-title"><a>Public collection title</a></p>
					</div>
				</li>

				<li class="snax-collections-item">
					<div class="snax-collection snax-collection-tpl-listxs snax-collection-private">
						<p class="snax-collection-title"><a>Private collection title</a></p>
					</div>
				</li>
			</ul>
		</div>
		<div class="snax-collections-leading">
			<div class="snax-collections-leading-icon"></div>
			<h3 class="snax-collections-leading-title">No Collections</h3>
			<p>Here you&#039;ll find all collections you&#039;ve created before.</p>
		</div>
	</div>
</div>
<script>(function() {function maybePrefixUrlField() {
	if (this.value.trim() !== '' && this.value.indexOf('http') !== 0) {
		this.value = "http://" + this.value;
	}
}

var urlFields = document.querySelectorAll('.mc4wp-form input[type="url"]');
if (urlFields) {
	for (var j=0; j < urlFields.length; j++) {
		urlFields[j].addEventListener('blur', maybePrefixUrlField);
	}
}
})();</script>
<script>
  (function(){
    if(typeof _bsa !== 'undefined' && _bsa) {
      _bsa.init('flexbar', 'CEADP27N', 'placement:htmldesign');
    }
  })();
</script>
<link rel='stylesheet' id='g1-socials-basic-screen-css'  href='https://html.design/wp-content/plugins/g1-socials/css/screen-basic.min.css?ver=1.2.27' type='text/css' media='all' />
<link rel='stylesheet' id='g1-socials-snapcode-css'  href='https://html.design/wp-content/plugins/g1-socials/css/snapcode.min.css?ver=1.2.27' type='text/css' media='all' />
<script type='text/javascript' src='https://html.design/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=5.6.3' id='swv-js'></script>
<script type='text/javascript' id='contact-form-7-js-extra'>
/* <![CDATA[ */
var wpcf7 = {"api":{"root":"https:\/\/html.design\/wp-json\/","namespace":"contact-form-7\/v1"},"cached":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='https://html.design/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.6.3' id='contact-form-7-js'></script>
<script type='text/javascript' src='https://html.design/wp-content/plugins/media-ace/includes/lazy-load/assets/js/youtube.js?ver=1.4.12' id='mace-lazy-load-youtube-js'></script>
<script type='text/javascript' src='https://html.design/wp-content/plugins/media-ace/includes/lazy-load/assets/js/lazysizes/lazysizes.min.js?ver=4.0' id='lazysizes-js'></script>
<script type='text/javascript' src='https://html.design/wp-content/plugins/media-ace/includes/lazy-load/assets/js/lazysizes/plugins/unveilhooks/ls.unveilhooks.min.js?ver=5.2.0' id='lazysizes-unveilhooks-js'></script>
<script type='text/javascript' id='mace-gallery-js-extra'>
/* <![CDATA[ */
var macegallery = {"i18n":{"of":"of"},"html":"\n<div class=\"g1-gallery-wrapper g1-gallery-dark\">\n\t<div class=\"g1-gallery\">\n\t\t<div class=\"g1-gallery-header\">\n\t\t\t<div class=\"g1-gallery-header-left\">\n\t\t\t\t<div class=\"g1-gallery-logo\">\n\t\t\t\t\t\t\t\t<\/div>\n\t\t\t\t<div class=\"g1-gallery-title g1-gamma g1-gamma-1st\">{title}<\/div>\n\t\t\t<\/div>\n\t\t\t<div class=\"g1-gallery-header-right\">\n\t\t\t\t<div class=\"g1-gallery-back-to-slideshow\">Back to slideshow<\/div>\n\t\t\t\t<div class=\"g1-gallery-thumbs-button\"><\/div>\n\t\t\t\t<div class=\"g1-gallery-numerator\">{numerator}<\/div>\n\t\t\t\t<div class=\"g1-gallery-close-button\"><\/div>\n\t\t\t<\/div>\n\t\t<\/div>\n\t\t<div class=\"g1-gallery-body\">\n\t\t\t<div class=\"g1-gallery-frames\">\n\t\t\t\t{frames}\n\t\t\t<\/div>\n\t\t\t<div class=\"g1-gallery-thumbnails32\">\n\t\t\t\t<div class=\"g1-gallery-thumbnails-collection\">\n\t\t\t\t\t{thumbnails32}\n\t\t\t\t<\/div>\n\t\t\t<\/div>\n\t\t\t<div class=\"g1-gallery-sidebar\">\n\t\t\t\t\t<div class=\"g1-gallery-shares\">\n\t\t\t\t\t<\/div>\n\t\t\t\t\t<div class=\"g1-gallery-ad\"><\/div>\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"g1-gallery-thumbnails\">\n\t\t\t\t\t\t\t<div class=\"g1-gallery-thumbnails-up\"><\/div>\n\t\t\t\t\t\t\t<div class=\"g1-gallery-thumbnails-collection\">{thumbnails}<\/div>\n\t\t\t\t\t\t\t<div class=\"g1-gallery-thumbnails-down\"><\/div>\n\t\t\t\t\t\t<\/div>\n\t\t\t\t\t\t\t\t<\/div>\n\t\t<\/div>\n\t<\/div>\n<\/div>\n","shares":""};
/* ]]> */
</script>
<script type='text/javascript' src='https://html.design/wp-content/plugins/media-ace/includes/gallery/js/gallery.js?ver=1.4.12' id='mace-gallery-js'></script>
<script type='text/javascript' id='snax-collections-js-extra'>
/* <![CDATA[ */
var snax_collections_js_config = {"ajax_url":"https:\/\/html.design\/wp-admin\/admin-ajax.php","home_url":"https:\/\/html.design","user_id":"0","post_id":"0","nonce":"1e0a5938e1","history":"off","i18n":{"are_you_sure_remove":"Entire collection with all items will be removed. Proceed?","are_you_sure_clear_all":"All collection items will be removed. Proceed?","removed":"Collection has been successfully removed","removing_items":"Removing collection items..."}};
/* ]]> */
</script>
<script type='text/javascript' src='https://html.design/wp-content/plugins/snax/assets/js/collections.min.js?ver=1.92' id='snax-collections-js'></script>
<script type='text/javascript' src='https://html.design/wp-content/plugins/snax/assets/js/jquery.magnific-popup/jquery.magnific-popup.min.js?ver=1.1.0' id='jquery-magnific-popup-js'></script>
<script type='text/javascript' src='https://html.design/wp-content/plugins/snax/assets/js/jquery.timeago/jquery.timeago.js?ver=1.5.2' id='jquery-timeago-js'></script>
<script type='text/javascript' src='https://html.design/wp-content/plugins/snax/assets/js/jquery.timeago/locales/jquery.timeago.en.js' id='jquery-timeago-en-js'></script>
<script type='text/javascript' id='snax-front-js-extra'>
/* <![CDATA[ */
var snax_front_config = {"ajax_url":"https:\/\/html.design\/wp-admin\/admin-ajax.php","site_url":"https:\/\/html.design","autosave_interval":"60","use_login_recaptcha":"","recaptcha_api_url":"https:\/\/www.google.com\/recaptcha\/api.js","recaptcha_version":"20","recaptcha_site_key":"","enable_login_popup":"1","login_url":"#","login_popup_url_var":"snax_login_popup","logged_in":"","login_success_var":"snax_login_success","delete_status_var":"snax_delete_status","item_comments_js_enabled":"1","i18n":{"are_you_sure":"Are you sure?","recaptcha_invalid":"<strong>ERROR<\/strong>: The reCAPTCHA you entered is incorrect.","passwords_dont_match":"Passwords don't match.","link_invalid":"Your password reset link appears to be invalid or expired.","password_set":"New password has been set","duplicate_comment":"Duplicate comment detected; it looks as though you&#8217;ve already said that!","comment_fail":"Comment Submission Failure","see_all_replies":"See all replies","user_is_logging":"Please wait. You are logging in&hellip;","points_singular_tpl":"<strong>%d<\/strong> Point","points_plural_tpl":"<strong>%d<\/strong> Points","points_singular_short_tpl":"<strong>%s<\/strong> Point","points_plural_short_tpl":"<strong>%s<\/strong> Points","popup_close_label":"Close (Esc)"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://html.design/wp-content/plugins/snax/assets/js/front.js?ver=1.92' id='snax-front-js'></script>
<script type='text/javascript' id='wyr-front-js-extra'>
/* <![CDATA[ */
var wyr_front_config = {"ajax_url":"https:\/\/html.design\/wp-admin\/admin-ajax.php","error_msg":"Some error occurred while voting. Please try again.","number_format":{"decimals":0,"dec_point":".","thousands_sep":","}};
/* ]]> */
</script>
<script type='text/javascript' src='https://html.design/wp-content/plugins/whats-your-reaction/js/front.js?ver=1.3.18' id='wyr-front-js'></script>
<script type='text/javascript' id='rocket-browser-checker-js-after'>
"use strict";var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||!1,descriptor.configurable=!0,"value"in descriptor&&(descriptor.writable=!0),Object.defineProperty(target,descriptor.key,descriptor)}}return function(Constructor,protoProps,staticProps){return protoProps&&defineProperties(Constructor.prototype,protoProps),staticProps&&defineProperties(Constructor,staticProps),Constructor}}();function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor))throw new TypeError("Cannot call a class as a function")}var RocketBrowserCompatibilityChecker=function(){function RocketBrowserCompatibilityChecker(options){_classCallCheck(this,RocketBrowserCompatibilityChecker),this.passiveSupported=!1,this._checkPassiveOption(this),this.options=!!this.passiveSupported&&options}return _createClass(RocketBrowserCompatibilityChecker,[{key:"_checkPassiveOption",value:function(self){try{var options={get passive(){return!(self.passiveSupported=!0)}};window.addEventListener("test",null,options),window.removeEventListener("test",null,options)}catch(err){self.passiveSupported=!1}}},{key:"initRequestIdleCallback",value:function(){!1 in window&&(window.requestIdleCallback=function(cb){var start=Date.now();return setTimeout(function(){cb({didTimeout:!1,timeRemaining:function(){return Math.max(0,50-(Date.now()-start))}})},1)}),!1 in window&&(window.cancelIdleCallback=function(id){return clearTimeout(id)})}},{key:"isDataSaverModeOn",value:function(){return"connection"in navigator&&!0===navigator.connection.saveData}},{key:"supportsLinkPrefetch",value:function(){var elem=document.createElement("link");return elem.relList&&elem.relList.supports&&elem.relList.supports("prefetch")&&window.IntersectionObserver&&"isIntersecting"in IntersectionObserverEntry.prototype}},{key:"isSlowConnection",value:function(){return"connection"in navigator&&"effectiveType"in navigator.connection&&("2g"===navigator.connection.effectiveType||"slow-2g"===navigator.connection.effectiveType)}}]),RocketBrowserCompatibilityChecker}();
</script>
<script type='text/javascript' id='rocket-preload-links-js-extra'>
/* <![CDATA[ */
var RocketPreloadLinksConfig = {"excludeUris":"\/(?:.+\/)?feed(?:\/(?:.+\/?)?)?$|\/(?:.+\/)?embed\/|\/(index\\.php\/)?wp\\-json(\/.*|$)|\/newadminjack\/|\/wp-admin\/|\/logout\/|#|\/refer\/|\/go\/|\/recommend\/|\/recommends\/","usesTrailingSlash":"1","imageExt":"jpg|jpeg|gif|png|tiff|bmp|webp|avif","fileExt":"jpg|jpeg|gif|png|tiff|bmp|webp|avif|php|pdf|html|htm","siteUrl":"https:\/\/html.design","onHoverDelay":"100","rateThrottle":"3"};
/* ]]> */
</script>
<script type='text/javascript' id='rocket-preload-links-js-after'>
(function() {
"use strict";var r="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},e=function(){function i(e,t){for(var n=0;n<t.length;n++){var i=t[n];i.enumerable=i.enumerable||!1,i.configurable=!0,"value"in i&&(i.writable=!0),Object.defineProperty(e,i.key,i)}}return function(e,t,n){return t&&i(e.prototype,t),n&&i(e,n),e}}();function i(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}var t=function(){function n(e,t){i(this,n),this.browser=e,this.config=t,this.options=this.browser.options,this.prefetched=new Set,this.eventTime=null,this.threshold=1111,this.numOnHover=0}return e(n,[{key:"init",value:function(){!this.browser.supportsLinkPrefetch()||this.browser.isDataSaverModeOn()||this.browser.isSlowConnection()||(this.regex={excludeUris:RegExp(this.config.excludeUris,"i"),images:RegExp(".("+this.config.imageExt+")$","i"),fileExt:RegExp(".("+this.config.fileExt+")$","i")},this._initListeners(this))}},{key:"_initListeners",value:function(e){-1<this.config.onHoverDelay&&document.addEventListener("mouseover",e.listener.bind(e),e.listenerOptions),document.addEventListener("mousedown",e.listener.bind(e),e.listenerOptions),document.addEventListener("touchstart",e.listener.bind(e),e.listenerOptions)}},{key:"listener",value:function(e){var t=e.target.closest("a"),n=this._prepareUrl(t);if(null!==n)switch(e.type){case"mousedown":case"touchstart":this._addPrefetchLink(n);break;case"mouseover":this._earlyPrefetch(t,n,"mouseout")}}},{key:"_earlyPrefetch",value:function(t,e,n){var i=this,r=setTimeout(function(){if(r=null,0===i.numOnHover)setTimeout(function(){return i.numOnHover=0},1e3);else if(i.numOnHover>i.config.rateThrottle)return;i.numOnHover++,i._addPrefetchLink(e)},this.config.onHoverDelay);t.addEventListener(n,function e(){t.removeEventListener(n,e,{passive:!0}),null!==r&&(clearTimeout(r),r=null)},{passive:!0})}},{key:"_addPrefetchLink",value:function(i){return this.prefetched.add(i.href),new Promise(function(e,t){var n=document.createElement("link");n.rel="prefetch",n.href=i.href,n.onload=e,n.onerror=t,document.head.appendChild(n)}).catch(function(){})}},{key:"_prepareUrl",value:function(e){if(null===e||"object"!==(void 0===e?"undefined":r(e))||!1 in e||-1===["http:","https:"].indexOf(e.protocol))return null;var t=e.href.substring(0,this.config.siteUrl.length),n=this._getPathname(e.href,t),i={original:e.href,protocol:e.protocol,origin:t,pathname:n,href:t+n};return this._isLinkOk(i)?i:null}},{key:"_getPathname",value:function(e,t){var n=t?e.substring(this.config.siteUrl.length):e;return n.startsWith("/")||(n="/"+n),this._shouldAddTrailingSlash(n)?n+"/":n}},{key:"_shouldAddTrailingSlash",value:function(e){return this.config.usesTrailingSlash&&!e.endsWith("/")&&!this.regex.fileExt.test(e)}},{key:"_isLinkOk",value:function(e){return null!==e&&"object"===(void 0===e?"undefined":r(e))&&(!this.prefetched.has(e.href)&&e.origin===this.config.siteUrl&&-1===e.href.indexOf("?")&&-1===e.href.indexOf("#")&&!this.regex.excludeUris.test(e.href)&&!this.regex.images.test(e.href))}}],[{key:"run",value:function(){"undefined"!=typeof RocketPreloadLinksConfig&&new n(new RocketBrowserCompatibilityChecker({capture:!0,passive:!0}),RocketPreloadLinksConfig).init()}}]),n}();t.run();
}());
</script>
<script type='text/javascript' src='https://html.design/wp-content/themes/bimber/js/stickyfill/stickyfill.min.js?ver=2.0.3' id='stickyfill-js'></script>
<script type='text/javascript' src='https://html.design/wp-content/themes/bimber/js/jquery.placeholder/placeholders.jquery.min.js?ver=4.0.1' id='jquery-placeholder-js'></script>
<script type='text/javascript' src='https://html.design/wp-content/themes/bimber/js/matchmedia/matchmedia.js' id='match-media-js'></script>
<script type='text/javascript' src='https://html.design/wp-content/themes/bimber/js/matchmedia/matchmedia.addlistener.js' id='match-media-add-listener-js'></script>
<script type='text/javascript' src='https://html.design/wp-content/themes/bimber/js/picturefill/picturefill.min.js?ver=2.3.1' id='picturefill-js'></script>
<script type='text/javascript' src='https://html.design/wp-content/themes/bimber/js/jquery.waypoints/jquery.waypoints.min.js?ver=4.0.0' id='jquery-waypoints-js'></script>
<script type='text/javascript' src='https://html.design/wp-content/themes/bimber/js/enquire/enquire.min.js?ver=2.1.2' id='enquire-js'></script>
<script type='text/javascript' id='bimber-global-js-extra'>
/* <![CDATA[ */
var bimber_front_config = {"debug_mode":"","ajax_url":"https:\/\/html.design\/wp-admin\/admin-ajax.php","timeago":"on","sharebar":"on","i18n":{"menu":{"go_to":"Go to"},"newsletter":{"subscribe_mail_subject_tpl":"Check out this great article: %subject%"},"bp_profile_nav":{"more_link":"More"}},"comment_types":["wp"],"auto_load_limit":"0","auto_play_videos":"","use_gif_player":"1","setTargetBlank":"1","useWaypoints":"1","stack":"cards","wpp":{"token":"ab61f213e9"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://html.design/wp-content/themes/bimber/js/global.js?ver=9.2.1' id='bimber-global-js'></script>
<script type='text/javascript' src='https://html.design/wp-includes/js/jquery/ui/core.min.js?ver=1.13.1' id='jquery-ui-core-js'></script>
<script type='text/javascript' src='https://html.design/wp-includes/js/jquery/ui/menu.min.js?ver=1.13.1' id='jquery-ui-menu-js'></script>
<script type='text/javascript' src='https://html.design/wp-includes/js/dist/vendor/regenerator-runtime.min.js?ver=0.13.9' id='regenerator-runtime-js'></script>
<script type='text/javascript' src='https://html.design/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=3.15.0' id='wp-polyfill-js'></script>
<script type='text/javascript' src='https://html.design/wp-includes/js/dist/dom-ready.min.js?ver=d996b53411d1533a84951212ab6ac4ff' id='wp-dom-ready-js'></script>
<script type='text/javascript' src='https://html.design/wp-includes/js/dist/hooks.min.js?ver=c6d64f2cb8f5c6bb49caca37f8828ce3' id='wp-hooks-js'></script>
<script type='text/javascript' src='https://html.design/wp-includes/js/dist/i18n.min.js?ver=ebee46757c6a411e38fd079a7ac71d94' id='wp-i18n-js'></script>
<script type='text/javascript' id='wp-i18n-js-after'>
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
</script>
<script type='text/javascript' src='https://html.design/wp-includes/js/dist/a11y.min.js?ver=a38319d7ba46c6e60f7f9d4c371222c5' id='wp-a11y-js'></script>
<script type='text/javascript' id='jquery-ui-autocomplete-js-extra'>
/* <![CDATA[ */
var uiAutocompleteL10n = {"noResults":"No results found.","oneResult":"1 result found. Use up and down arrow keys to navigate.","manyResults":"%d results found. Use up and down arrow keys to navigate.","itemSelected":"Item selected."};
/* ]]> */
</script>
<script type='text/javascript' src='https://html.design/wp-includes/js/jquery/ui/autocomplete.min.js?ver=1.13.1' id='jquery-ui-autocomplete-js'></script>
<script type='text/javascript' src='https://html.design/wp-content/themes/bimber/js/ajax-search.js?ver=9.2.1' id='bimber-ajax-search-js'></script>
<script type='text/javascript' src='https://www.google.com/recaptcha/api.js?render=6LesAr0UAAAAABdXjQEtu62MwI3uz9ugs4yTvaFD&#038;ver=3.0' id='google-recaptcha-js'></script>
<script type='text/javascript' id='wpcf7-recaptcha-js-extra'>
/* <![CDATA[ */
var wpcf7_recaptcha = {"sitekey":"6LesAr0UAAAAABdXjQEtu62MwI3uz9ugs4yTvaFD","actions":{"homepage":"homepage","contactform":"contactform"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://html.design/wp-content/plugins/contact-form-7/modules/recaptcha/index.js?ver=5.6.3' id='wpcf7-recaptcha-js'></script>
<script type='text/javascript' src='https://cdn.onesignal.com/sdks/OneSignalSDK.js?ver=6.0.2' async='async' id='remote_sdk-js'></script>
<script type='text/javascript' src='https://html.design/wp-content/themes/bimber/js/back-to-top.js?ver=9.2.1' id='bimber-back-to-top-js'></script>
<script type='text/javascript' defer src='https://html.design/wp-content/plugins/mailchimp-for-wp/assets/js/forms.js?ver=4.8.10' id='mc4wp-forms-api-js'></script>
<div class="g1-popup g1-popup-newsletter">
	<div class="g1-popup-overlay">
	</div>

	<div class="g1-popup-inner">
		
<div id="bimber-mc4wp-form-counter-1" class="g1-newsletter g1-newsletter-vertical ">
	<div class="g1-newsletter-cover">
									<div class="g1-newsletter-cover-background lazyload" data-bg="https://html.design/wp-content/uploads/2020/05/Screen-Shot-2020-05-23-at-2.20.32-AM.png">
			

			</div>
			</div>

	<div class="g1-newsletter-content">
		<h3 class="g1-mega g1-mega-1st">Hey Friend!
Before You Go Please subscribe.</h3>

					<p>Get the Latest HTML Templates straight into your inbox before everyone else!</p>
		
		<div class="g1-newsletter-form-wrap">
			<script>(function() {
	window.mc4wp = window.mc4wp || {
		listeners: [],
		forms: {
			on: function(evt, cb) {
				window.mc4wp.listeners.push(
					{
						event   : evt,
						callback: cb
					}
				);
			}
		}
	}
})();
</script><!-- Mailchimp for WordPress v4.8.10 - https://wordpress.org/plugins/mailchimp-for-wp/ --><form id="mc4wp-form-2" class="mc4wp-form mc4wp-form-4468" method="post" data-id="4468" data-name="Default sign-up form" ><div class="mc4wp-form-fields"><p>
	<label>Email address: </label>
	<input type="email" name="EMAIL" placeholder="Your email address" required />
</p>

<p>
	<input type="submit" value="Sign up" />
</p></div><label style="display: none !important;">Leave this field empty if you're human: <input type="text" name="_mc4wp_honeypot" value="" tabindex="-1" autocomplete="off" /></label><input type="hidden" name="_mc4wp_timestamp" value="1663819132" /><input type="hidden" name="_mc4wp_form_id" value="4468" /><input type="hidden" name="_mc4wp_form_element_id" value="mc4wp-form-2" /><div class="mc4wp-response"></div><p class="g1-meta g1-newsletter-privacy">Don&#039;t worry, we don&#039;t spam</p></form><!-- / Mailchimp for WordPress Plugin -->		</div>
	</div>
</div><!-- .g1-newsletter -->

		<a href="#" class="g1-popup-closer">Close</a>
	</div>
</div><!-- .g1-popup -->

<div class="wpgdprc wpgdprc-consent-modal" id="wpgdprc-consent-modal" aria-hidden="true">
	<div class="wpgdprc-consent-modal__overlay" tabindex="-1" data-micromodal-close>
		<div class="wpgdprc-consent-modal__inner" role="dialog" aria-modal="true">
			<div class="wpgdprc-consent-modal__header">
				<p class="wpgdprc-consent-modal__title">Privacy settings</p>
				<button class="wpgdprc-consent-modal__close" aria-label="Close popup" data-micromodal-close>
					<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path d="M193.94 256L296.5 153.44l21.15-21.15c3.12-3.12 3.12-8.19 0-11.31l-22.63-22.63c-3.12-3.12-8.19-3.12-11.31 0L160 222.06 36.29 98.34c-3.12-3.12-8.19-3.12-11.31 0L2.34 120.97c-3.12 3.12-3.12 8.19 0 11.31L126.06 256 2.34 379.71c-3.12 3.12-3.12 8.19 0 11.31l22.63 22.63c3.12 3.12 8.19 3.12 11.31 0L160 289.94 262.56 392.5l21.15 21.15c3.12 3.12 8.19 3.12 11.31 0l22.63-22.63c3.12-3.12 3.12-8.19 0-11.31L193.94 256z"/></svg>
				</button>
			</div>
            
<div class="wpgdprc-consent-modal__body">
	<nav class="wpgdprc-consent-modal__navigation">
		<ul class="wpgdprc-consent-modal__navigation-list">
			<li class="wpgdprc-consent-modal__navigation-item">
				<button class="wpgdprc-consent-modal__navigation-button wpgdprc-consent-modal__navigation-button--active" data-target="description">Privacy Settings</button>
			</li>
											<li>
					<button class="wpgdprc-consent-modal__navigation-button" data-target="1">HTML Template</button>
				</li>
					</ul>
	</nav>

	<div class="wpgdprc-consent-modal__information">
		<div class="wpgdprc-consent-modal__description wpgdprc-consent-modal__description--active" data-target="description">
			<p class="wpgdprc-consent-modal__title wpgdprc-consent-modal__title--description">Privacy Settings</p>
			<div class="wpgdprc-content-modal__content">
				<p>This site uses functional cookies and external scripts to improve your experience. Which cookies and scripts are used and how they impact your visit is specified on the left. You may change your settings at any time. Your choices will not impact your visit.</p>
<p><span class="wpgdprc-text--warning"><strong>NOTE:</strong> These settings will only apply to the browser and device you are currently using.</span></p>
			</div>
		</div>

								<div class="wpgdprc-consent-modal__description" data-target="1">
				<p class="wpgdprc-consent-modal__title wpgdprc-consent-modal__title--description">HTML Template</p>
				<div class="wpgdprc-content-modal__content">
									</div>
									<div class="wpgdprc-content-modal__options">
						
<div class="wpgdprc-checkbox">
	<label class="wpgdprc-switch wpgdprc-switch--column wpgdprc-switch--border" for="1">
		<span class="wpgdprc-switch__text">Enable?</span>
		<span class="wpgdprc-switch__switch">
			<input class="wpgdprc-switch__input" type="checkbox" id="1" name="1" value="1"  />
			<span class="wpgdprc-switch__slider round">
				
<span data-icon="check" class="icon--wrap">
	<svg class="icon">
		<use href=https://html.design/wp-content/plugins/wp-gdpr-compliance/Assets/icons//sprite-fontawesome-pro-regular.svg#check></use>
	</svg>
</span>
				
<span data-icon="times" class="icon--wrap">
	<svg class="icon">
		<use href=https://html.design/wp-content/plugins/wp-gdpr-compliance/Assets/icons//sprite-fontawesome-pro-regular.svg#times></use>
	</svg>
</span>
			</span>
		</span>
	</label>
</div>
					</div>
							</div>
			</div>
</div>
<div class="wpgdprc-consent-modal__footer">
	<div class="wpgdprc-consent-modal__footer__information">
		<a href="https://cookieinformation.com/?utm_campaign=van-ons-go-premium&#038;utm_source=van-ons-wp&#038;utm_medium=referral" target="_blank">Powered by Cookie Information</a>
	</div>
	<button class="wpgdprc-button wpgdprc-button--secondary">Save my settings</button>
</div>
		</div>
	</div>
</div>
<script>window.lazyLoadOptions={elements_selector:"img[data-lazy-src],.rocket-lazyload",data_src:"lazy-src",data_srcset:"lazy-srcset",data_sizes:"lazy-sizes",class_loading:"lazyloading",class_loaded:"lazyloaded",threshold:300,callback_loaded:function(element){if(element.tagName==="IFRAME"&&element.dataset.rocketLazyload=="fitvidscompatible"){if(element.classList.contains("lazyloaded")){if(typeof window.jQuery!="undefined"){if(jQuery.fn.fitVids){jQuery(element).parent().fitVids()}}}}}};window.addEventListener('LazyLoad::Initialized',function(e){var lazyLoadInstance=e.detail.instance;if(window.MutationObserver){var observer=new MutationObserver(function(mutations){var image_count=0;var iframe_count=0;var rocketlazy_count=0;mutations.forEach(function(mutation){for(var i=0;i<mutation.addedNodes.length;i++){if(typeof mutation.addedNodes[i].getElementsByTagName!=='function'){continue}
if(typeof mutation.addedNodes[i].getElementsByClassName!=='function'){continue}
images=mutation.addedNodes[i].getElementsByTagName('img');is_image=mutation.addedNodes[i].tagName=="IMG";iframes=mutation.addedNodes[i].getElementsByTagName('iframe');is_iframe=mutation.addedNodes[i].tagName=="IFRAME";rocket_lazy=mutation.addedNodes[i].getElementsByClassName('rocket-lazyload');image_count+=images.length;iframe_count+=iframes.length;rocketlazy_count+=rocket_lazy.length;if(is_image){image_count+=1}
if(is_iframe){iframe_count+=1}}});if(image_count>0||iframe_count>0||rocketlazy_count>0){lazyLoadInstance.update()}});var b=document.getElementsByTagName("body")[0];var config={childList:!0,subtree:!0};observer.observe(b,config)}},!1)</script><script data-no-minify="1" async src="https://html.design/wp-content/plugins/wp-rocket/assets/js/lazyload/17.5/lazyload.min.js"></script></body>
</html>
<!-- plugin=object-cache-pro client=phpredis metric#hits=11306 metric#misses=207 metric#hit-ratio=98.2 metric#bytes=1289395 metric#prefetches=0 metric#store-reads=341 metric#store-writes=2 metric#store-hits=399 metric#store-misses=8 metric#sql-queries=56 metric#ms-total=431.14 metric#ms-cache=40.46 metric#ms-cache-median=0.08 metric#ms-cache-ratio=8.6 sample#redis-hits=297458279 sample#redis-misses=17259010 sample#redis-hit-ratio=94.5 sample#redis-ops-per-sec=300 sample#redis-evicted-keys=0 sample#redis-used-memory=31311304 sample#redis-used-memory-rss=40361984 sample#redis-memory-fragmentation-ratio=1.3 sample#redis-connected-clients=1 sample#redis-tracking-clients=0 sample#redis-rejected-connections=0 sample#redis-keys=33676 -->
